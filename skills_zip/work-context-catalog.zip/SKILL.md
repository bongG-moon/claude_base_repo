---
name: work-context-catalog
description: "Claude와 Codex에서 어떤 업무를 했는지 정리하고, 저장한 스킬과 참고 자료를 함께 볼 수 있는 보고서를 만듭니다. 다시 쓸 자료와 처리 과정을 찾아볼 때 사용합니다."
---

# AI 업무 기록 정리

실제 지침은 [work-context-catalog](source/skills/work-context-catalog/SKILL.md)입니다. 해당 본문을 읽고 요청한 작업만 진행하세요.
상대 링크와 스킬 폴더는 `source/skills/work-context-catalog` 기준입니다. 현재 문맥에서 읽은 동일 본문은 재사용합니다.

Company Agent 없이 사용 가능합니다. 필요한 Python 등 의존성은 INSTALL.md를 확인하세요.

설치·제거는 [INSTALL.md](INSTALL.md)를 참고하세요. Skill 호출만으로 설치기·의존성 설치·플랫폼 게시를 실행하지 않습니다.
