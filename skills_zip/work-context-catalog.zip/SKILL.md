---
name: work-context-catalog
description: "지정한 프로젝트의 스킬·기억·지식과 현재 사용자의 Claude·Codex 세션 기록을 출처별로 정리해 업무현황 HTML과 재집계 자료를 만듭니다. 상시 수집이나 개인 평가 도구는 아닙니다."
---

# 업무 맥락 모아 보기

실제 지침은 [work-context-catalog](source/skills/work-context-catalog/SKILL.md)입니다. 해당 본문을 읽고 요청한 작업만 진행하세요.
상대 링크와 스킬 폴더는 `source/skills/work-context-catalog` 기준입니다. 현재 문맥에서 읽은 동일 본문은 재사용합니다.

Company Agent 없이 사용 가능합니다. 필요한 Python 등 의존성은 INSTALL.md를 확인하세요.

설치·제거는 [INSTALL.md](INSTALL.md)를 참고하세요. Skill 호출만으로 설치기·의존성 설치·플랫폼 게시를 실행하지 않습니다.
