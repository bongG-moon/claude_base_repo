---
name: personal-memory
description: "개인 선호, 업무 맥락을 범위를 선택해 Markdown 파일로 저장하고 조회하거나 수정합니다. 자동 학습, 대화 주입은 포함하지 않습니다."
---

# 개인 선호와 업무 기억 관리

실제 지침은 [personal-memory](source/skills/personal-memory/SKILL.md)입니다. 해당 본문을 읽고 요청한 작업만 진행하세요.
상대 링크와 스킬 폴더는 `source/skills/personal-memory` 기준입니다. 현재 문맥에서 읽은 동일 본문은 재사용합니다.

이 ZIP에 필요한 작업 지침과 실행 자료가 포함되어 있습니다. 별도 하네스 설치는 필요하지 않으며, Python 등 사용 환경은 INSTALL.md를 확인하세요.

설치·제거는 [INSTALL.md](INSTALL.md)를 참고하세요. Skill 호출만으로 설치기·의존성 설치·플랫폼 게시를 실행하지 않습니다.
