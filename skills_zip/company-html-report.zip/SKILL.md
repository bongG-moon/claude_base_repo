---
name: square-company-html-report
description: "업무 자료를 디자인·분량·표시 방식에 맞춰 오프라인 HTML 보고서로 만듭니다. 요청 시 작업 흐름과 구조도 설명합니다. Company Agent 실행 환경이 필요합니다."
---

# 오프라인 HTML 업무 보고서

실제 지침은 [html-report](source/skills/html-report/SKILL.md)입니다. 해당 본문을 읽고 요청한 작업만 진행하세요.
상대 링크와 스킬 폴더는 `source/skills/html-report` 기준입니다. 현재 문맥에서 읽은 동일 본문은 재사용합니다.

기존 Company Agent 런타임과 원본이 요구하는 세션 문맥이 필요합니다. 없으면 제한을 안내하고 임의 CLI 경로·세션을 만들지 마세요.

설치·제거는 [INSTALL.md](INSTALL.md)를 참고하세요. Skill 호출만으로 설치기·의존성 설치·플랫폼 게시를 실행하지 않습니다.
