---
name: website-rebuild
description: "URL이나 화면 이미지를 참고해 웹 디자인과 필요한 동작을 재현합니다. 실제 확인한 화면과 추정한 부분을 구분하고 기존 프로젝트에 편집 가능한 코드로 만듭니다."
---

# 참고 화면으로 웹 만들기

실제 지침은 [website-rebuild](source/skills/website-rebuild/SKILL.md)입니다. 해당 본문을 읽고 요청한 작업만 진행하세요.
상대 링크와 스킬 폴더는 `source/skills/website-rebuild` 기준입니다. 현재 문맥에서 읽은 동일 본문은 재사용합니다.

이 ZIP에 필요한 작업 지침과 실행 자료가 포함되어 있습니다. 별도 하네스 설치는 필요하지 않으며, Python 등 사용 환경은 INSTALL.md를 확인하세요.

설치·제거는 [INSTALL.md](INSTALL.md)를 참고하세요. Skill 호출만으로 설치기·의존성 설치·플랫폼 게시를 실행하지 않습니다.
