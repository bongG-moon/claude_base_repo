---
name: square-company-outlook-assistant
description: "메일 제목·발신자·날짜로 후보를 좁힌 뒤 필요한 본문을 읽어 요약과 답장 초안, 정리 계획을 만듭니다. 회사 Outlook 연결과 권한이 필요합니다."
---

# Outlook 메일 업무 도우미

실제 지침은 [outlook-assistant](source/skills/outlook-assistant/SKILL.md)입니다. 해당 본문을 읽고 요청한 작업만 진행하세요.
상대 링크와 스킬 폴더는 `source/skills/outlook-assistant` 기준입니다. 현재 문맥에서 읽은 동일 본문은 재사용합니다.

기존 Company Agent 런타임과 원본이 요구하는 세션 문맥이 필요합니다. 없으면 제한을 안내하고 임의 CLI 경로·세션을 만들지 마세요.

설치·제거는 [INSTALL.md](INSTALL.md)를 참고하세요. Skill 호출만으로 설치기·의존성 설치·플랫폼 게시를 실행하지 않습니다.
