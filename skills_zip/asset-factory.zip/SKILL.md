---
name: asset-factory
description: "개인 스킬, Python 스크립트, 표준 tools.py MCP를 만들고 수정합니다. 현재 연결된 도구와 기본 스킬 폴더를 활용하며 등록, 배포는 별도입니다."
---

# 스킬과 도구 제작 도우미

실제 지침은 [asset-factory](source/skills/asset-factory/SKILL.md)입니다. 해당 본문을 읽고 요청한 작업만 진행하세요.
상대 링크와 스킬 폴더는 `source/skills/asset-factory` 기준입니다. 현재 문맥에서 읽은 동일 본문은 재사용합니다.

이 ZIP에 필요한 작업 지침과 실행 자료가 포함되어 있습니다. 별도 하네스 설치는 필요하지 않으며, Python 등 사용 환경은 INSTALL.md를 확인하세요.

설치·제거는 [INSTALL.md](INSTALL.md)를 참고하세요. Skill 호출만으로 설치기·의존성 설치·플랫폼 게시를 실행하지 않습니다.
