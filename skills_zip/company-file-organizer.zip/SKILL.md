---
name: square-company-file-organizer
description: "Windows 폴더의 파일 정리 계획을 먼저 보여주고 승인 후 종류별로 이동합니다. 삭제·덮어쓰기 없이 정리하며 기록을 이용해 되돌립니다. Company Agent 실행 환경이 필요합니다."
---

# 되돌릴 수 있는 폴더 정리

실제 지침은 [file-organizer](source/skills/file-organizer/SKILL.md)입니다. 해당 본문을 읽고 요청한 작업만 진행하세요.
상대 링크와 스킬 폴더는 `source/skills/file-organizer` 기준입니다. 현재 문맥에서 읽은 동일 본문은 재사용합니다.

기존 Company Agent 런타임과 원본이 요구하는 세션 문맥이 필요합니다. 없으면 제한을 안내하고 임의 CLI 경로·세션을 만들지 마세요.

설치·제거는 [INSTALL.md](INSTALL.md)를 참고하세요. Skill 호출만으로 설치기·의존성 설치·플랫폼 게시를 실행하지 않습니다.
