---
name: html-report
description: "수치와 근거를 보존하며 선택한 글꼴과 디자인으로 HTML 보고서를 만듭니다. 데이터 표는 검색, 정렬, 페이지 이동과 CSV 다운로드를 지원하며 스토리형, 데이터 리포트형, 발표형 레퍼런스를 선택할 수 있습니다."
---

# 오프라인 HTML 업무 보고서

실제 지침은 [html-report](source/skills/html-report/SKILL.md)입니다. 해당 본문을 읽고 요청한 작업만 진행하세요.
상대 링크와 스킬 폴더는 `source/skills/html-report` 기준입니다. 현재 문맥에서 읽은 동일 본문은 재사용합니다.

Company Agent 없이 사용 가능합니다. 필요한 Python 등 의존성은 INSTALL.md를 확인하세요.

설치·제거는 [INSTALL.md](INSTALL.md)를 참고하세요. Skill 호출만으로 설치기·의존성 설치·플랫폼 게시를 실행하지 않습니다.
