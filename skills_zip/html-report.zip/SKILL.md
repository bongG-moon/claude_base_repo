---
name: html-report
description: "기존 HTML이나 여러 참고 이미지의 색 조합, 글꼴, 표와 그래프 구성을 새 내용에 적용하는 오프라인 HTML 보고서입니다. 디자인 선택을 유지하며 표 검색, 정렬, 페이지 이동과 CSV 다운로드를 제공합니다."
---

# 오프라인 HTML 업무 보고서

실제 지침은 [html-report](source/skills/html-report/SKILL.md)입니다. 해당 본문을 읽고 요청한 작업만 진행하세요.
상대 링크와 스킬 폴더는 `source/skills/html-report` 기준입니다. 현재 문맥에서 읽은 동일 본문은 재사용합니다.

이 ZIP에 필요한 작업 지침과 실행 자료가 포함되어 있습니다. 별도 하네스 설치는 필요하지 않으며, Python 등 사용 환경은 INSTALL.md를 확인하세요.

설치·제거는 [INSTALL.md](INSTALL.md)를 참고하세요. Skill 호출만으로 설치기·의존성 설치·플랫폼 게시를 실행하지 않습니다.
