---
name: html-report
description: "정리한 내용을 HTML 보고서로 만듭니다. 갤러리에서 실제 사례를 참고한 10가지 디자인과 3가지 구성을 비교하고, 글꼴과 조건을 골라 채팅에 전달합니다. 기존 양식을 참고하고 표 탐색과 다운로드까지 제공합니다."
---

# 오프라인 HTML 업무 보고서

실제 지침은 [html-report](source/skills/html-report/SKILL.md)입니다. 해당 본문을 읽고 요청한 작업만 진행하세요.
상대 링크와 스킬 폴더는 `source/skills/html-report` 기준입니다. 현재 문맥에서 읽은 동일 본문은 재사용합니다.

이 ZIP에 필요한 작업 지침과 실행 자료가 포함되어 있습니다. 별도 하네스 설치는 필요하지 않으며, Python 등 사용 환경은 INSTALL.md를 확인하세요.

설치·제거는 [INSTALL.md](INSTALL.md)를 참고하세요. Skill 호출만으로 설치기·의존성 설치·플랫폼 게시를 실행하지 않습니다.
