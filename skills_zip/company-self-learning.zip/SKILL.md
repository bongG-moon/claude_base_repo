---
name: square-company-self-learning
description: "지속적인 명시적 교정과 검증된 반복 선택·개인 절차 개선을 학습 후보로 접수합니다. 모델 훈련이 아닌 Company Agent 내부 학습 지원 Skill입니다."
company-agent-role: support
---

# 검증된 교정·절차 학습

실제 지침은 [self-learning](source/skills/self-learning/SKILL.md)입니다. 해당 본문을 읽고 요청한 작업만 진행하세요.
상대 링크와 스킬 폴더는 `source/skills/self-learning` 기준입니다. 현재 문맥에서 읽은 동일 본문은 재사용합니다.

기존 Company Agent 런타임과 원본이 요구하는 세션 문맥이 필요합니다. 없으면 제한을 안내하고 임의 CLI 경로·세션을 만들지 마세요.

설치·제거는 [INSTALL.md](INSTALL.md)를 참고하세요. Skill 호출만으로 설치기·의존성 설치·플랫폼 게시를 실행하지 않습니다.
