---
name: karpathy-guidelines
description: "코드, 스크립트, MCP, 실행형 스킬 제작과 검토에서 범위를 작게 유지하고 기존 코드를 활용하며 실제 근거로 결과를 확인하도록 돕는 개발 지침입니다."
license: MIT
---

# 근거로 확인하는 개발 지침

실제 지침은 [karpathy-guidelines](source/skills/karpathy-guidelines/SKILL.md)입니다. 해당 본문을 읽고 요청한 작업만 진행하세요.
상대 링크와 스킬 폴더는 `source/skills/karpathy-guidelines` 기준입니다. 현재 문맥에서 읽은 동일 본문은 재사용합니다.

이 ZIP에 필요한 작업 지침과 실행 자료가 포함되어 있습니다. 별도 하네스 설치는 필요하지 않으며, Python 등 사용 환경은 INSTALL.md를 확인하세요.

설치·제거는 [INSTALL.md](INSTALL.md)를 참고하세요. Skill 호출만으로 설치기·의존성 설치·플랫폼 게시를 실행하지 않습니다.
