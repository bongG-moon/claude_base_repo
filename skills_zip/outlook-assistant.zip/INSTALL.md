# Outlook 메일 업무 도우미 — 설치와 사용

메일 목록을 먼저 좁힌 뒤 필요한 본문만 읽어 요약, 답장 초안을 만듭니다. 기존 메일 연결, Classic Outlook 또는 선택한 EML을 사용합니다.

## 사용 환경
이 ZIP 하나에 작업 지침과 실행 자료가 들어 있습니다. 별도 하네스 설치는 필요하지 않으며, 아래 프로그램이나 연결은 사용하는 기능에 따라 필요합니다.
- 현재 호스트에 실제 제공되는 메일 연결 또는 실행 중인 Windows Classic Outlook이 필요합니다.
- 로컬 Classic Outlook 도우미는 Python 3.11 이상과 pywin32가 필요합니다. 새 Outlook/Web Outlook은 COM 대상이 아닙니다.
- EML 파일 읽기는 Python 표준 라이브러리만 필요합니다. 이 ZIP은 MCP 서버나 계정 연결을 설치하지 않습니다.
- 검색 목록, 읽을 본문, 총 글자수를 제한합니다. 로컬 도우미는 읽기 전용이며 발송, 이동, 삭제를 제공하지 않습니다.
- 포함된 설치 도우미는 Python 3.11 이상과 표준 라이브러리만 사용합니다.

## 먼저 설치 범위 선택
1. ZIP을 별도의 폴더에 압축 해제합니다. 설치기를 실행한다고 자동으로 전역 설치되지 않습니다.
2. **현재 프로젝트** 또는 **내 계정 전역** 중 직접 선택합니다. 전역은 모든 PC 사용자가 아니라 본인 계정입니다.
3. PowerShell에서 실제 업무 폴더로 이동한 뒤 아래 명령에서 압축 해제한 설치기의 경로를 넣습니다.

```powershell
python -X utf8 "압축해제폴더/install_skill.py"
```

프로그램이 설치 범위와 실제 대상 경로를 보여줍니다. 빈 선택은 전역 설치로 처리하지 않으며 q로 취소할 수 있습니다. 프로젝트 위치를 명시하려면 다음처럼 실행합니다.

```powershell
python -X utf8 "압축해제폴더/install_skill.py" --scope project --project-dir "업무폴더의 절대경로"
```

실행 전에 경로만 확인하려면 `--dry-run`을 더합니다. 비대화형 실행은 `--scope project` 또는 `--scope user`와 `--yes`를 모두 직접 지정해야 합니다. 의존성 설치, Claude 설정·모델·MCP·후크 변경은 하지 않습니다.

## 수동 설치도 가능
- 프로젝트 선택: `<업무폴더>/.claude/skills/outlook-assistant/`를 새로 만들고 ZIP의 모든 파일을 그 안에 복사합니다.
- 내 계정 전역 선택: `~/.claude/skills/outlook-assistant/`에 복사합니다. `CLAUDE_CONFIG_DIR`를 사용하는 환경은 해당 설정 폴더의 `skills/outlook-assistant/`를 사용합니다.
- `SKILL.md` 하나만 복사하지 마세요. `source/`의 Python 코드·참고자료·리소스가 함께 있어야 합니다.
- 같은 이름의 설치 폴더가 이미 있으면 덮어쓰지 말고 기존 폴더를 별도 백업한 뒤 새 패키지를 설치합니다. 예전 `square-company-outlook-assistant` 설치가 같은 범위에 있어도 중복 설치하지 않습니다. 기존 개인 수정 내용을 비교해 보관한 뒤 예전 폴더를 스킬 검색 경로 밖으로 옮기고 새 이름으로 설치합니다. 플러그인 캐시와 개인 기억·지식 저장소는 변경하지 않습니다.

## 실행
Claude Code에서 해당 프로젝트를 열고 새 대화를 시작한 뒤 `/outlook-assistant`와 함께 할 일을 적습니다. 실제 본문은 `source/skills/outlook-assistant/SKILL.md`에 있습니다. 그 본문에서 말하는 스킬 폴더는 해당 하위 폴더입니다. 다른 호스트는 그 제품의 스킬 설치 위치에 전체 폴더를 두세요. 이 설치기는 Claude Code의 파일 위치만 지원하며 다른 제품의 설정을 변경하지 않습니다.
등록용 원본 `packageId`와 설치 폴더 이름은 `outlook-assistant`입니다. 다른 스킬이나 하네스를 먼저 설치할 필요는 없습니다.


## 새 버전 및 제거
P&T AI SQUARE의 같은 도구에서 새 버전을 등록합니다. 새 원본 `packageId`는 `outlook-assistant`이며 이후에도 이 이름을 유지합니다. 예전에 `company.skills.outlook-assistant`로 등록한 도구도 기존 도구를 선택해 업데이트할 수 있습니다. 이때 플랫폼의 고정 ID는 과거 값으로 남을 수 있고, 새 파일의 원본 ID는 `outlook-assistant`로 표시됩니다. 설치 이름과 실행에는 영향이 없습니다. 플랫폼이 배포 번호를 부여하며 이 ZIP은 자동 업데이트나 플랫폼 접속을 요구하지 않습니다.
제거는 위에서 본인이 선택한 `skills/outlook-assistant` 폴더만 삭제합니다. 설치 도우미가 추가로 설정한 항목은 없습니다.

## 플랫폼 등록
도구 등록 → 파일 선택에서 이 ZIP 자체를 선택합니다. 이름·설명·프로그램 Claude·유형 Skill·업무 태그·설치 안내·동작 흐름이 배포 정보에서 읽힙니다. 조직·업무 분류와 공개/승인 필요 여부는 등록자가 화면에서 선택합니다. 이 ZIP을 만든 작업은 서버 게시나 실제 PC 설치를 수행하지 않습니다.

설치 위치 참고: https://code.claude.com/docs/en/skills
