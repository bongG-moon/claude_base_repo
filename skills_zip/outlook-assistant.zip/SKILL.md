---
name: outlook-assistant
description: "메일 목록을 먼저 좁힌 뒤 필요한 본문만 읽어 요약, 답장 초안을 만듭니다. 기존 메일 연결, Classic Outlook 또는 선택한 EML을 사용합니다."
---

# Outlook 메일 업무 도우미

실제 지침은 [outlook-assistant](source/skills/outlook-assistant/SKILL.md)입니다. 해당 본문을 읽고 요청한 작업만 진행하세요.
상대 링크와 스킬 폴더는 `source/skills/outlook-assistant` 기준입니다. 현재 문맥에서 읽은 동일 본문은 재사용합니다.

이 ZIP에 필요한 작업 지침과 실행 자료가 포함되어 있습니다. 별도 하네스 설치는 필요하지 않으며, Python 등 사용 환경은 INSTALL.md를 확인하세요.

설치·제거는 [INSTALL.md](INSTALL.md)를 참고하세요. Skill 호출만으로 설치기·의존성 설치·플랫폼 게시를 실행하지 않습니다.
