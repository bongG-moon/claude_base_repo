"""Host-neutral tools: metadata -> registered dataset -> local result reference."""
from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Callable

from .config import MCPError, load_settings, oracle_profile, read_profiles
from .metadata import MetadataRepository
from .oracle import execute_dataset
from .results import KST, ResultStore


class OracleMetadataService:
    def __init__(self, config_dir: Path, repository_factory: Callable = MetadataRepository, executor: Callable = execute_dataset):
        self.config_dir = config_dir.resolve()
        self.repository_factory = repository_factory
        self.executor = executor

    def _repository(self):
        settings = load_settings(self.config_dir)
        settings.require_mongo()
        return self.repository_factory(settings)

    def configuration_status(self, check_mongodb: bool = False) -> dict:
        result = {"config_dir": str(self.config_dir), "env_file": str(self.config_dir / ".env"), "oracle_config_file": str(self.config_dir / "oracle_connections.toml"), "current_time_kst": datetime.now(KST).isoformat(), "issues": [], "oracle_profiles": []}
        settings = load_settings(self.config_dir)
        try:
            settings.require_mongo()
        except MCPError as exc:
            result["issues"].append(exc.as_dict())
        try:
            for db_key in read_profiles(self.config_dir):
                try:
                    oracle_profile(self.config_dir, db_key)
                    result["oracle_profiles"].append({"db_key": db_key, "configured": True})
                except MCPError as exc:
                    result["oracle_profiles"].append({"db_key": db_key, "configured": False})
                    result["issues"].append(exc.as_dict())
        except MCPError as exc:
            result["issues"].append(exc.as_dict())
        if not result["oracle_profiles"]:
            result["issues"].append({"code": "oracle_configuration_required", "message": "Oracle DB 접속 블록이 없습니다."})
        if check_mongodb:
            try:
                result["mongodb"] = self._repository().status()
            except MCPError as exc:
                result["issues"].append(exc.as_dict())
        result.update(configured=not result["issues"], connections_checked=bool(check_mongodb), oracle_connections_checked=False, result_directory=str(settings.result_dir))
        return result

    def search_metadata(self, query: str = "", kind: str = "all", limit: int = 20, offset: int = 0) -> dict:
        return self._repository().search(query=query, kind=kind, limit=limit, offset=offset)

    def get_metadata(self, kind: str, key: str) -> dict:
        return self._repository().get(kind=kind, key=key)

    def check_oracle_connection(self, db_key: str) -> dict:
        settings = load_settings(self.config_dir)
        profile = oracle_profile(self.config_dir, db_key)
        result = self.executor({"dataset_key": "connection_check", "source_type": "oracle", "source_config": {"db_key": db_key, "query_template": "SELECT 1 AS MCP_CONNECTION_OK FROM DUAL"}, "columns": ["MCP_CONNECTION_OK"]}, {}, {}, profile, max_rows=1, timeout_seconds=settings.query_timeout_seconds)
        return {"db_key": db_key, "connected": True, "rows": result.get("rows", [])}

    def query_dataset(self, dataset_key: str, parameters: dict | None = None, filters: dict | None = None, row_limit: int | None = None) -> dict:
        settings = load_settings(self.config_dir)
        parameters = {} if parameters is None else parameters
        filters = {} if filters is None else filters
        if not isinstance(parameters, dict) or not isinstance(filters, dict):
            raise MCPError("invalid_query_arguments", "parameters와 filters는 JSON object여야 합니다.")
        if row_limit is None:
            row_limit = settings.max_rows
        if isinstance(row_limit, bool) or not isinstance(row_limit, int) or not 1 <= row_limit <= settings.max_rows:
            raise MCPError("invalid_row_limit", f"row_limit은 1~{settings.max_rows} 범위여야 합니다.")
        record = self._repository().get("table_catalog", dataset_key)
        catalog = record["payload"]
        config = catalog.get("source_config") or {}
        source_type = str(catalog.get("source_type") or catalog.get("source") or config.get("source_type") or "").lower()
        if source_type not in {"oracle", "oracle_db", "oracledb"}:
            raise MCPError("unsupported_source", "이번 MCP는 Oracle Catalog만 실행합니다.", {"dataset_key": dataset_key, "source_type": source_type})
        db_key = str(config.get("db_key") or catalog.get("db_key") or "")
        if not db_key:
            raise MCPError("missing_db_key", "선택한 Catalog에 source_config.db_key가 없습니다.")
        profile = oracle_profile(self.config_dir, db_key)
        data = self.executor(catalog, parameters, filters, profile, max_rows=row_limit, timeout_seconds=settings.query_timeout_seconds)
        rows = data.get("rows", [])
        response = {key: value for key, value in data.items() if key != "rows"}
        response.update(dataset_key=record.get("key", dataset_key), db_key=db_key, row_count=len(rows), preview_rows=rows[:settings.preview_rows], preview_only=len(rows) > settings.preview_rows)
        response.setdefault("params", parameters)
        response.setdefault("filters", filters)
        response["complete"] = bool(data.get("complete", True)) and not data.get("truncated", False) and not data.get("truncated_cells", 0)
        if data.get("truncated"):
            response["next_action"] = "원본이 잘렸습니다. 전체 건수/합계/평균으로 답하지 말고 필수 조회 조건으로 범위를 줄이거나 ORACLE_MAX_ROWS를 조정해 다시 조회하세요. filters는 조회 후 적용이므로 원본 잘림을 해결하지 못합니다."
        elif not response["complete"]:
            response["next_action"] = "일부 셀 값이 잘리거나 변환되지 않았습니다. warnings를 확인하고 해당 값에 의존하는 필터/계산 결과를 완전한 결과로 단정하지 마세요."
        try:
            response["artifact"] = ResultStore(settings.result_dir, settings.result_max_bytes).save(data, response["dataset_key"])
        except MCPError as exc:
            response["artifact_error"] = exc.as_dict()
            response["available_rows"] = len(response["preview_rows"])
            response["complete"] = False
            response["next_action"] = "조회는 끝났지만 전체 결과 파일 저장에 실패했습니다. 미리보기만으로 전체 분석을 완료하지 마세요."
        return response

    def read_result(self, result_id: str, offset: int = 0, limit: int = 100) -> dict:
        settings = load_settings(self.config_dir)
        return ResultStore(settings.result_dir, settings.result_max_bytes).read(result_id, offset, limit)
