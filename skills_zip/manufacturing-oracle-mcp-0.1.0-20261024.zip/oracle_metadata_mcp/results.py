"""Bounded local result artifacts; no Mongo sessions, no arbitrary file reads."""
from __future__ import annotations

import csv
import io
import json
import re
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path

from .config import MCPError

KST = timezone(timedelta(hours=9))


class ResultStore:
    def __init__(self, directory: Path, max_bytes: int):
        self.directory = directory
        self.max_bytes = max_bytes

    def save(self, result: dict, dataset_key: str) -> dict:
        result_id = uuid.uuid4().hex
        rows = result.get("rows", [])
        columns = result.get("columns", [])
        metadata = {k: v for k, v in result.items() if k != "rows"}
        metadata.update(result_id=result_id, dataset_key=dataset_key, row_count=len(rows), created_at=datetime.now(KST).isoformat())
        info = json.dumps(metadata, ensure_ascii=False, allow_nan=False, indent=2).encode("utf-8")
        target = self.directory / result_id
        size = len(info)
        created = False
        completed = False

        def write_limited(handle, content: bytes):
            nonlocal size
            size += len(content)
            if size > self.max_bytes:
                raise MCPError("result_too_large", "결과 저장 용량 제한을 초과했습니다. row_limit을 줄이거나 RESULT_MAX_MIB를 조정하세요.")
            handle.write(content)

        try:
            target.mkdir(parents=True, exist_ok=False)
            created = True
            # Serialize one row at a time; do not duplicate a full result in memory.
            stream = io.StringIO(newline="")
            writer = csv.DictWriter(stream, fieldnames=columns, extrasaction="raise")
            with (target / "rows.jsonl").open("xb") as jsonl, (target / "rows.csv").open("xb") as csv_file:
                writer.writeheader()
                write_limited(csv_file, stream.getvalue().encode("utf-8-sig"))
                for row in rows:
                    write_limited(jsonl, (json.dumps(row, ensure_ascii=False, allow_nan=False) + "\n").encode("utf-8"))
                    stream.seek(0)
                    stream.truncate(0)
                    writer.writerow({key: _csv_value(row.get(key)) for key in columns})
                    write_limited(csv_file, stream.getvalue().encode("utf-8"))
            # Index is written last so read_result never accepts incomplete artifacts.
            (target / "metadata.json").write_bytes(info)
            completed = True
        except OSError:
            raise MCPError("result_save_failed", "Oracle 조회는 완료됐지만 로컬 결과 파일을 저장하지 못했습니다. 결과 폴더 권한과 여유 공간을 확인하세요.") from None
        finally:
            # Only this freshly generated UUID folder is touched; never a prior result.
            if created and not completed:
                for name in ("rows.jsonl", "rows.csv", "metadata.json"):
                    try:
                        (target / name).unlink(missing_ok=True)
                    except OSError:
                        pass
                try:
                    target.rmdir()
                except OSError:
                    pass
        return {"result_id": result_id, "row_count": len(rows), "created_at": metadata["created_at"], "jsonl_path": str(target / "rows.jsonl"), "csv_path": str(target / "rows.csv"), "metadata_path": str(target / "metadata.json")}

    def read(self, result_id: str, offset: int = 0, limit: int = 100) -> dict:
        if not re.fullmatch(r"[0-9a-f]{32}", result_id):
            raise MCPError("invalid_result_id", "query_dataset이 반환한 result_id를 사용하세요.")
        if isinstance(offset, bool) or isinstance(limit, bool) or offset < 0 or not 1 <= limit <= 200:
            raise MCPError("invalid_page", "offset은 0 이상, limit은 1~200이어야 합니다.")
        target = self.directory / result_id
        # Prevent result folder symlinks from exposing other local files.
        if target.resolve().parent != self.directory.resolve():
            raise MCPError("invalid_result_id", "허용된 결과 경로가 아닙니다.")
        try:
            metadata_path = target / "metadata.json"
            rows_path = target / "rows.jsonl"
            if metadata_path.is_symlink() or rows_path.is_symlink():
                raise MCPError("invalid_result_id", "허용된 결과 파일이 아닙니다.")
            if metadata_path.stat().st_size + rows_path.stat().st_size > self.max_bytes:
                raise MCPError("result_too_large", "저장 결과가 현재 파일 크기 제한을 초과했습니다.")
            metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
            rows = []
            with rows_path.open(encoding="utf-8") as source:
                for i, line in enumerate(source):
                    if i < offset:
                        continue
                    if len(rows) >= limit:
                        break
                    rows.append(json.loads(line))
        except (OSError, ValueError):
            raise MCPError("result_unavailable", "이 결과 파일을 찾거나 읽을 수 없습니다. 원래 dataset_key와 조회 조건으로 다시 조회하세요.") from None
        return {"result_id": result_id, "dataset_key": metadata.get("dataset_key"), "created_at": metadata.get("created_at"), "columns": metadata.get("columns", []), "rows": rows, "row_count": metadata.get("row_count", 0), "offset": offset, "next_offset": offset + len(rows) if offset + len(rows) < metadata.get("row_count", 0) else None, "truncated": metadata.get("truncated", False), "complete": bool(metadata.get("complete", True)) and not metadata.get("truncated", False) and not metadata.get("truncated_cells", 0), "truncated_cells": metadata.get("truncated_cells", 0), "warnings": metadata.get("warnings", []), "fetched_row_count": metadata.get("fetched_row_count"), "params": metadata.get("params", {}), "filters": metadata.get("filters", {})}


def _csv_value(value):
    if isinstance(value, (dict, list)):
        return json.dumps(value, ensure_ascii=False)
    return value
