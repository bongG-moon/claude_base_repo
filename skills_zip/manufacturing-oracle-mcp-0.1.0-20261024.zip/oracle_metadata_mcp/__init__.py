"""Local metadata-guided Oracle tools; the host owns reasoning and conversation."""

__version__ = "0.1.0"
