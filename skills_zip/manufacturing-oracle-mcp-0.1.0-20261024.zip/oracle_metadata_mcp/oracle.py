"""Execute registered Oracle SELECT templates with binds and bounded results.

There is deliberately no API for accepting SQL from an MCP caller. Catalog SQL
is configuration, and database credentials still need read-only privileges.
"""
from __future__ import annotations

import base64
import math
import re
import threading
from datetime import date, datetime
from decimal import Decimal, InvalidOperation
from typing import Any

from .config import MCPError


_NAME = r"[A-Za-z_][A-Za-z0-9_]*"
_PLACEHOLDER = re.compile(r"\{\{\s*(" + _NAME + r")\s*\}\}|\{\s*(" + _NAME + r")\s*\}")
_BIND = re.compile(r"(?<!:):(" + _NAME + r")\b")
_DRIVER_LOCK = threading.Lock()
_MAX_CELL_CHARS = 20_000
_OPERATORS = {"eq", "ne", "in", "not_in", "gt", "ge", "lt", "le", "between", "contains", "startswith", "endswith", "is_null", "not_null"}


def _parts(sql: str) -> list[tuple[str, str]]:
    """Split SQL literals/comments so placeholders in comments never bind."""
    parts: list[tuple[str, str]] = []
    i = start = 0
    while i < len(sql):
        kind = ""
        end = i
        if sql.startswith("--", i):
            kind = "comment"
            end = sql.find("\n", i)
            end = len(sql) if end < 0 else end + 1
        elif sql.startswith("/*", i):
            kind = "comment"
            end = sql.find("*/", i + 2)
            if end < 0:
                raise MCPError("invalid_catalog_sql", "등록 SQL의 주석이 닫히지 않았습니다.")
            end += 2
        elif sql[i:i + 2].lower() == "q'" and i + 2 < len(sql):
            kind = "literal"
            closer = {"[": "]", "(": ")", "{": "}", "<": ">"}.get(sql[i + 2], sql[i + 2])
            end = sql.find(closer + "'", i + 3)
            if end < 0:
                raise MCPError("invalid_catalog_sql", "등록 SQL의 문자열이 닫히지 않았습니다.")
            end += 2
        elif sql[i] in "'\"":
            quote = sql[i]
            kind = "string" if quote == "'" else "identifier"
            end = i + 1
            while end < len(sql):
                if sql[end] == quote:
                    if end + 1 < len(sql) and sql[end + 1] == quote:
                        end += 2
                        continue
                    end += 1
                    break
                end += 1
            else:
                raise MCPError("invalid_catalog_sql", "등록 SQL의 문자열 또는 컬럼명이 닫히지 않았습니다.")
        if kind:
            if start < i:
                parts.append(("code", sql[start:i]))
            parts.append((kind, sql[i:end]))
            i = start = end
        else:
            i += 1
    if start < len(sql):
        parts.append(("code", sql[start:]))
    return parts


def _parameter_names(catalog: dict[str, Any]) -> set[str]:
    names: set[str] = set()
    for owner in (catalog, catalog.get("source_config") or {}):
        required = owner.get("required_params") or []
        if isinstance(required, dict):
            required = list(required)
        if isinstance(required, str):
            required = [required]
        for item in required:
            if isinstance(item, dict):
                if item.get("required", True):
                    name = item.get("name") or item.get("key") or item.get("parameter")
                    if name:
                        names.add(str(name).upper())
            elif item:
                names.add(str(item).upper())
        mappings = owner.get("required_param_mappings") or {}
        if isinstance(mappings, dict):
            names.update(str(key).upper() for key in mappings)
    return names


def compile_query(catalog: dict[str, Any], params: dict[str, Any]) -> tuple[str, dict[str, Any]]:
    """Resolve old literal placeholders and native binds without interpolation."""
    if not isinstance(catalog, dict) or not isinstance(params, dict):
        raise MCPError("invalid_query_input", "catalog와 params는 객체여야 합니다.")
    config = catalog.get("source_config") or {}
    source = str(catalog.get("source_type") or config.get("source_type") or "oracle").lower()
    if source not in {"oracle", "oracle_db", "oracledb"}:
        raise MCPError("unsupported_source", "이 MCP는 Oracle 데이터셋만 조회합니다.")
    template = next((str(owner[key]).strip() for owner in (config, catalog)
                     for key in ("query_template", "sql_template", "oracle_sql", "sql", "query")
                     if owner.get(key)), "")
    if not template:
        raise MCPError("missing_query_template", "등록된 Oracle 조회 SQL이 없습니다.")
    normalized: dict[str, Any] = {}
    for key, value in params.items():
        if not re.fullmatch(_NAME, str(key)):
            raise MCPError("invalid_parameter", "파라미터 이름은 등록된 식별자여야 합니다.")
        name = str(key).upper()
        if name in normalized:
            raise MCPError("duplicate_parameter", f"대소문자만 다른 파라미터가 중복됐습니다: {name}")
        normalized[name] = value
    missing = sorted(name for name in _parameter_names(catalog)
                     if name not in normalized or normalized[name] is None or normalized[name] == "" or normalized[name] == [])
    if missing:
        raise MCPError("missing_required_params", "필수 조회 조건을 params에 입력해 주세요. filters와는 별개입니다.", {"missing_params": missing})
    pieces = _parts(template)
    native_names = {match.group(1).upper() for kind, text in pieces if kind == "code" for match in _BIND.finditer(text)}
    used: set[str] = set()
    bindings: dict[str, Any] = {}
    index = 0

    def add_bind(value: Any) -> str:
        nonlocal index
        if isinstance(value, bool) or isinstance(value, (dict, list, tuple, set)):
            raise MCPError("invalid_parameter_value", "SQL 파라미터 값은 문자열, 숫자, 날짜 또는 그 목록이어야 합니다.")
        if not isinstance(value, (str, int, float, Decimal, date, datetime, type(None))):
            raise MCPError("invalid_parameter_value", "지원하지 않는 SQL 파라미터 자료형입니다.")
        if isinstance(value, (float, Decimal)) and not math.isfinite(value):
            raise MCPError("invalid_parameter_value", "SQL 숫자 파라미터는 유한해야 합니다.")
        if isinstance(value, str) and len(value) > 32_767:
            raise MCPError("invalid_parameter_value", "SQL 파라미터 문자열이 너무 깁니다.")
        while True:
            index += 1
            name = f"mcp_p{index}"
            if name.upper() not in native_names:
                break
        bindings[name] = value
        return ":" + name

    def value_for(name: str) -> Any:
        name = name.upper()
        if name not in normalized:
            raise MCPError("missing_required_params", "SQL에 필요한 조회 조건을 params에 입력해 주세요.", {"missing_params": [name]})
        used.add(name)
        return normalized[name]

    def bind_name(name: str) -> str:
        value = value_for(name)
        if isinstance(value, (list, tuple)):
            if not value or len(value) > 1000:
                raise MCPError("invalid_parameter_value", "목록 파라미터는 1~1,000개 값으로 입력해 주세요.")
            return ", ".join(add_bind(item) for item in value)
        return add_bind(value)

    def template_match(match: re.Match[str]) -> str:
        return bind_name(match.group(1) or match.group(2))

    rendered: list[str] = []
    for kind, text in pieces:
        if kind == "code":
            # Native binds are substituted before generated placeholder binds.
            text = _BIND.sub(lambda match: bind_name(match.group(1)), text)
            text = _PLACEHOLDER.sub(template_match, text)
        elif kind == "string":
            literal = text[1:-1].replace("''", "'")
            full = _PLACEHOLDER.fullmatch(literal)
            if full:
                text = template_match(full)
            elif _PLACEHOLDER.search(literal):
                def compose(match: re.Match[str]) -> str:
                    value = value_for(match.group(1) or match.group(2))
                    if isinstance(value, (list, tuple, dict, set)) or value is None:
                        raise MCPError("invalid_parameter_value", "문자열 내부 파라미터에는 단일 값을 입력해 주세요.")
                    return str(value)
                text = add_bind(_PLACEHOLDER.sub(compose, literal))
        elif kind in {"identifier", "literal"} and _PLACEHOLDER.search(text):
            raise MCPError("unsupported_template_placeholder", "식별자 또는 Oracle q 문자열 내부 placeholder는 일반 bind 형태로 등록해 주세요.")
        rendered.append(text)
    unknown = sorted(set(normalized) - used)
    if unknown:
        raise MCPError("unused_query_params", "등록 SQL에 없는 조건입니다. 조회 후 조건은 filters로 전달해 주세요.", {"unused_params": unknown})
    sql = "".join(rendered).strip()
    validate_readonly_sql(sql)
    final_parts = _parts(sql)
    for offset in range(len(final_parts) - 1, -1, -1):
        kind, text = final_parts[offset]
        if kind == "code" and text.strip():
            final_parts[offset] = (kind, text.rstrip().removesuffix(";"))
            break
    return "".join(text for _, text in final_parts), bindings


def validate_readonly_sql(sql: str) -> None:
    import sqlglot
    from sqlglot import exp

    # Parser compatibility only: execution retains comments/hints and q strings.
    # Comments after a semicolon can otherwise appear as an extra parsed node.
    validation_sql = "".join(
        " " if kind == "comment" else
        "'" + text[3:-2].replace("'", "''") + "'" if kind == "literal" else text
        for kind, text in _parts(sql)
    )
    try:
        statements = [item for item in sqlglot.parse(validation_sql, read="oracle") if item is not None]
    except Exception:
        raise MCPError("invalid_catalog_sql", "등록 SQL을 Oracle SELECT로 해석하지 못했습니다. 카탈로그 쿼리를 확인해 주세요.") from None
    if len(statements) != 1 or not isinstance(statements[0], (exp.Select, exp.SetOperation)):
        raise MCPError("query_not_readonly", "등록된 단일 SELECT 또는 WITH SELECT만 실행할 수 있습니다.")
    prohibited = (exp.DML, exp.DDL, exp.Command, exp.Into, exp.Lock)
    for node in statements[0].walk():
        if isinstance(node, prohibited):
            raise MCPError("query_not_readonly", "데이터 변경, SELECT INTO, 행 잠금 구문은 실행할 수 없습니다.")
        if isinstance(node, exp.Column) and node.name.upper() == "NEXTVAL":
            raise MCPError("query_not_readonly", "시퀀스 값을 변경하는 NEXTVAL은 실행할 수 없습니다.")


def _filter_specs(filters: dict[str, Any]) -> list[tuple[str, str, Any]]:
    if not isinstance(filters, dict):
        raise MCPError("invalid_filters", "filters는 표준 컬럼명과 조건의 객체여야 합니다.")
    specs: list[tuple[str, str, Any]] = []
    for field, condition in filters.items():
        if not isinstance(field, str) or not field.strip():
            raise MCPError("invalid_filters", "필터 컬럼명이 비어 있습니다.")
        if isinstance(condition, dict):
            if set(condition) - {"operator", "value"}:
                raise MCPError("invalid_filters", "필터는 operator와 value 항목만 지원합니다.")
            operator = str(condition.get("operator") or "eq").lower()
            if "value" not in condition and operator not in {"is_null", "not_null"}:
                raise MCPError("invalid_filters", f"필터 값이 없습니다: {field}")
            value = condition.get("value")
        else:
            operator, value = ("in", condition) if isinstance(condition, list) else ("eq", condition)
        if operator not in _OPERATORS:
            raise MCPError("invalid_filter_operator", f"지원하지 않는 필터 연산자입니다: {operator}", {"supported": sorted(_OPERATORS)})
        if operator in {"in", "not_in", "between"}:
            if not isinstance(value, list) or not value or len(value) > 1000 or (operator == "between" and len(value) != 2):
                raise MCPError("invalid_filters", f"{field}의 {operator}에는 올바른 값 목록이 필요합니다.")
            candidates = value
        else:
            candidates = [value]
        for item in candidates:
            if isinstance(item, (dict, list, tuple, set, bool)) or not isinstance(item, (str, int, float, Decimal, date, datetime, type(None))):
                raise MCPError("invalid_filters", f"{field}의 필터 값 자료형을 확인해 주세요.")
            if isinstance(item, (float, Decimal)) and not math.isfinite(item):
                raise MCPError("invalid_filters", f"{field}의 숫자 값은 유한해야 합니다.")
        specs.append((field, operator, value))
    return specs


def _number(value: Any) -> Decimal | None:
    if value is None or isinstance(value, bool):
        return None
    try:
        number = Decimal(str(value).strip())
        return number if number.is_finite() else None
    except (InvalidOperation, ValueError):
        return None


def _equal(actual: Any, expected: Any) -> bool:
    if actual is None or expected is None:
        return actual is None and expected is None
    # Numeric parameters compare safely to Oracle strings, without equating two
    # different text identifiers such as "001" and "1".
    if isinstance(actual, (int, float, Decimal)) or isinstance(expected, (int, float, Decimal)):
        a, b = _number(actual), _number(expected)
        if a is not None and b is not None:
            return a == b
    return str(actual).strip() == str(expected).strip()


def _matches(actual: Any, operator: str, expected: Any) -> bool:
    if operator == "is_null":
        return actual is None
    if operator == "not_null":
        return actual is not None
    if operator == "eq":
        return _equal(actual, expected)
    if operator == "ne":
        return not _equal(actual, expected)
    if operator in {"in", "not_in"}:
        found = any(_equal(actual, value) for value in expected)
        return found if operator == "in" else not found
    if actual is None or expected is None:
        return False
    if operator == "contains":
        return str(expected) in str(actual)
    if operator == "startswith":
        return str(actual).startswith(str(expected))
    if operator == "endswith":
        return str(actual).endswith(str(expected))
    if operator == "between":
        return _matches(actual, "ge", expected[0]) and _matches(actual, "le", expected[1])
    a, b = _number(actual), _number(expected)
    if a is None or b is None:
        a, b = str(actual), str(expected)
    return {"gt": a > b, "ge": a >= b, "lt": a < b, "le": a <= b}[operator]


def _columns(catalog: dict[str, Any], raw_columns: list[str]) -> tuple[list[str], dict[str, str], list[str]]:
    columns = list(raw_columns)
    if len({name.casefold() for name in columns}) != len(columns):
        raise MCPError("duplicate_result_columns", "Oracle 결과에 중복 컬럼명이 있습니다. 카탈로그 SELECT에 고유 alias를 지정해 주세요.")
    lookup = {name.casefold(): name for name in columns}
    mapping: dict[str, str] = {}
    warnings: list[str] = []
    mappings = catalog.get("filter_mappings") or {}
    if not isinstance(mappings, dict):
        raise MCPError("invalid_filter_mappings", "카탈로그 filter_mappings는 표준 컬럼과 물리 컬럼의 객체여야 합니다.")
    for canonical, physical in mappings.items():
        canonical = str(canonical)
        candidates = physical if isinstance(physical, list) else [physical]
        existing = [lookup[str(item).casefold()] for item in candidates if str(item).casefold() in lookup]
        if existing:
            selected = existing[0]
            if len(set(existing)) > 1:
                warnings.append(f"{canonical}: 여러 원본 컬럼 중 첫 등록 컬럼 {selected}를 사용했습니다. 원본 컬럼은 함께 보존됩니다.")
        elif canonical.casefold() in lookup:
            selected = lookup[canonical.casefold()]
        else:
            continue
        mapping[canonical] = selected
        if canonical not in columns:
            columns.append(canonical)
    return columns, mapping, warnings


def _json_cell(value: Any, shortened: list[int]) -> Any:
    if hasattr(value, "read") and callable(value.read):
        value = value.read(1, _MAX_CELL_CHARS + 1)
    if isinstance(value, (str, bytes)) and len(value) > _MAX_CELL_CHARS:
        shortened[0] += 1
        value = value[:_MAX_CELL_CHARS]
    if isinstance(value, (datetime, date)):
        return value.isoformat()
    if isinstance(value, Decimal):
        return int(value) if value.is_finite() and value == value.to_integral_value() else str(value)
    if isinstance(value, bytes):
        return {"encoding": "base64", "value": base64.b64encode(value).decode("ascii")}
    if isinstance(value, float) and not math.isfinite(value):
        return None
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    return str(value)


def execute_dataset(catalog: dict[str, Any], params: dict[str, Any], filters: dict[str, Any], profile: dict[str, Any], *, max_rows: int, timeout_seconds: int, driver: Any = None) -> dict[str, Any]:
    """Fetch a bounded registered source, add canonical aliases and post-filter."""
    if not isinstance(max_rows, int) or isinstance(max_rows, bool) or not 1 <= max_rows <= 1_000_000:
        raise MCPError("invalid_row_limit", "max_rows는 1~1,000,000 사이 정수여야 합니다.")
    if not isinstance(timeout_seconds, int) or isinstance(timeout_seconds, bool) or not 1 <= timeout_seconds <= 3600:
        raise MCPError("invalid_query_timeout", "조회 timeout_seconds는 1~3,600 사이 정수여야 합니다.")
    sql, binds = compile_query(catalog, params)
    specs = _filter_specs(filters)
    if not all(profile.get(key) for key in ("user", "password", "dsn")):
        raise MCPError("oracle_profile_incomplete", "Oracle 설정 파일에 user, password, dsn을 채워 주세요.")
    if driver is None:
        import oracledb as driver
    mode = str(profile.get("mode") or "thin").lower()
    if mode not in {"thin", "thick"}:
        raise MCPError("invalid_oracle_mode", "Oracle mode는 thin 또는 thick이어야 합니다.")
    conn = cursor = None
    shortened = [0]
    try:
        options = {"tcp_connect_timeout": float(profile.get("connect_timeout_seconds", 10))}
        if profile.get("config_dir"):
            options["config_dir"] = profile["config_dir"]
        with _DRIVER_LOCK:
            if mode == "thick" and driver.is_thin_mode():
                driver.init_oracle_client(lib_dir=profile.get("client_lib_dir") or None, config_dir=profile.get("config_dir") or None)
            elif mode == "thin" and not driver.is_thin_mode():
                raise MCPError("oracle_mode_conflict", "같은 MCP 프로세스에서 thin과 thick을 혼용할 수 없습니다. 설정을 통일하고 재시작해 주세요.")
            conn = driver.connect(user=profile["user"], password=profile["password"], dsn=profile["dsn"], **options)
        conn.autocommit = False
        conn.call_timeout = timeout_seconds * 1000
        cursor = conn.cursor()
        cursor.arraysize = min(1000, max_rows + 1)
        cursor.execute("SET TRANSACTION READ ONLY")
        cursor.execute(sql, binds)
        if cursor.description is None:
            raise MCPError("query_not_readonly", "조회 결과 컬럼이 없습니다. SELECT 카탈로그인지 확인해 주세요.")
        raw_columns = [str(item[0]) for item in cursor.description]
        columns, mapping, warnings = _columns(catalog, raw_columns)
        lookup = {column.casefold(): column for column in columns}
        unknown = [field for field, _, _ in specs if field.casefold() not in lookup]
        if unknown:
            raise MCPError("unknown_filter_columns", "조회 결과에 없는 필터 컬럼입니다. 적용하지 않은 조건으로 결과를 반환하지 않습니다.", {"columns": unknown, "available_columns": columns})
        records = cursor.fetchmany(max_rows + 1)
        truncated = len(records) > max_rows
        rows = []
        for record in records[:max_rows]:
            row = {column: _json_cell(value, shortened) for column, value in zip(raw_columns, record)}
            original_names = {column.casefold(): column for column in raw_columns}
            for canonical, physical in mapping.items():
                original = original_names.get(canonical.casefold())
                if original and original != physical and not _equal(row[original], row[physical]):
                    raise MCPError("conflicting_column_mapping", "표준 컬럼과 매핑된 원본 컬럼이 서로 다른 값을 반환했습니다. 카탈로그의 컬럼 연결을 확인해 주세요.",
                                   {"canonical_column": canonical, "physical_column": physical})
            row.update({canonical: row[physical] for canonical, physical in mapping.items()})
            if all(_matches(row[lookup[field.casefold()]], operator, value) for field, operator, value in specs):
                rows.append(row)
        if truncated:
            warnings.append("원본 조회 한도를 초과했습니다. 필터 결과가 0건이어도 전체 원본의 0건을 의미하지 않으며 전체 합계/평균으로 해석하면 안 됩니다. 범위를 좁혀 다시 조회하거나 한도를 조정해 주세요.")
        if shortened[0]:
            warnings.append(f"큰 문자열/LOB {shortened[0]}개 값을 {_MAX_CELL_CHARS:,}자/바이트로 제한했습니다.")
        return {"rows": rows, "columns": columns, "raw_columns": raw_columns, "column_mapping": mapping,
                "params": dict(params), "filters": dict(filters), "fetched_row_count": min(len(records), max_rows),
                "row_count": len(rows), "truncated": truncated, "complete": not truncated and not shortened[0],
                "truncated_cells": shortened[0], "warnings": warnings}
    except MCPError:
        raise
    except Exception as error:
        info = error.args[0] if error.args else None
        code = getattr(info, "full_code", None)
        details = {"driver_code": str(code)} if isinstance(code, str) and re.fullmatch(r"[A-Z]+-\d+", code) else None
        raise MCPError("oracle_query_failed", "Oracle 연결 또는 조회에 실패했습니다. 네트워크, DB 접속 설정, 조회 권한 및 등록 쿼리를 확인해 주세요.", details) from None
    finally:
        if cursor is not None:
            try:
                cursor.close()
            except Exception:
                pass
        if conn is not None:
            try:
                conn.rollback()
            except Exception:
                pass
            try:
                conn.close()
            except Exception:
                pass
