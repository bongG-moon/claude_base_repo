"""Explicit, non-mutating configuration loading. Never echo connection secrets."""
from __future__ import annotations

import os
import shutil
import tomllib
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from dotenv import dotenv_values


class MCPError(Exception):
    def __init__(self, code: str, message: str, details: Any = None):
        super().__init__(message)
        self.code, self.message, self.details = code, message, details

    def as_dict(self) -> dict:
        result = {"code": self.code, "message": self.message}
        if self.details is not None:
            result["details"] = self.details
        return result


@dataclass
class Settings:
    config_dir: Path
    mongo_uri: str = field(default="", repr=False)
    mongo_database: str = ""
    collections: dict[str, str] = field(default_factory=dict)
    mongo_timeout_ms: int = 5000
    metadata_limit: int = 2000
    max_rows: int = 50000
    query_timeout_seconds: int = 60
    preview_rows: int = 20
    result_max_bytes: int = 50 * 1024 * 1024
    result_dir: Path = Path("results")

    def require_mongo(self) -> None:
        missing = []
        if not self.mongo_uri:
            missing.append("MONGODB_URI")
        if not self.mongo_database:
            missing.append("MONGODB_DATABASE")
        for kind, env_key in COLLECTION_KEYS.items():
            if not self.collections.get(kind):
                missing.append(env_key)
        if missing:
            raise MCPError("configuration_required", "config/.env에 MongoDB 연결 정보를 입력하세요.", {"file": str(self.config_dir / ".env"), "missing": missing})
        if not self.mongo_uri.startswith(("mongodb://", "mongodb+srv://")):
            raise MCPError("invalid_mongodb_uri", "MONGODB_URI는 HTTP API 주소가 아닌 MongoDB 연결 URI여야 합니다.")


COLLECTION_KEYS = {
    "domain": "MONGODB_DOMAIN_COLLECTION",
    "table_catalog": "MONGODB_TABLE_CATALOG_COLLECTION",
    "main_filter": "MONGODB_MAIN_FILTER_COLLECTION",
}


def init_config(config_dir: Path) -> list[str]:
    """Explicit setup only: existing files, including empty ones, are preserved."""
    templates = Path(__file__).resolve().parent.parent
    config_dir.mkdir(parents=True, exist_ok=True)
    created = []
    for template, name in (("env.example", ".env"), ("oracle_connections.example.toml", "oracle_connections.toml")):
        target = config_dir / name
        if not target.exists():
            # Exclusive creation avoids overwriting a concurrently created config.
            with target.open("xb") as dest, (templates / template).open("rb") as source:
                shutil.copyfileobj(source, dest)
            created.append(str(target))
    return created


def load_settings(config_dir: Path) -> Settings:
    config_dir = config_dir.expanduser().resolve()
    env_file = config_dir / ".env"
    values: dict[str, Any] = {}
    if env_file.exists():
        try:
            values = dict(dotenv_values(env_file, encoding="utf-8-sig", interpolate=False))
        except (OSError, UnicodeError):
            raise MCPError("invalid_configuration", ".env 파일을 UTF-8 형식으로 읽을 수 없습니다.") from None
    # Explicit process values override this file; never search parents or load repo .env.
    def value(key: str, default: str = "") -> str:
        return str(os.environ.get(key, values.get(key, default)) or "")

    def integer(key: str, default: int, low: int, high: int) -> int:
        try:
            number = int(value(key, str(default)))
        except (ValueError, TypeError):
            raise MCPError("invalid_configuration", f"{key}에는 정수를 입력하세요.") from None
        if not low <= number <= high:
            raise MCPError("invalid_configuration", f"{key}는 {low}~{high} 범위여야 합니다.")
        return number

    result_dir = Path(value("RESULT_DIRECTORY", "../results")).expanduser()
    if not result_dir.is_absolute():
        result_dir = config_dir / result_dir
    return Settings(
        config_dir=config_dir,
        mongo_uri=value("MONGODB_URI").strip(),
        mongo_database=value("MONGODB_DATABASE").strip(),
        collections={kind: value(key).strip() for kind, key in COLLECTION_KEYS.items()},
        mongo_timeout_ms=integer("MONGODB_TIMEOUT_MS", 5000, 100, 120000),
        metadata_limit=integer("METADATA_SCAN_LIMIT", 2000, 1, 100000),
        max_rows=integer("ORACLE_MAX_ROWS", 50000, 1, 1000000),
        query_timeout_seconds=integer("ORACLE_QUERY_TIMEOUT_SECONDS", 60, 1, 3600),
        preview_rows=integer("RESULT_PREVIEW_ROWS", 20, 1, 200),
        result_max_bytes=integer("RESULT_MAX_MIB", 50, 1, 1024) * 1024 * 1024,
        result_dir=result_dir.resolve(),
    )


def read_profiles(config_dir: Path) -> dict[str, dict]:
    path = config_dir / "oracle_connections.toml"
    if not path.exists():
        raise MCPError("configuration_required", "Oracle 접속 설정 파일을 생성하고 입력하세요.", {"file": str(path)})
    try:
        payload = tomllib.loads(path.read_text(encoding="utf-8-sig"))
    except (OSError, UnicodeError, tomllib.TOMLDecodeError):
        raise MCPError("invalid_oracle_configuration", "oracle_connections.toml의 TOML 문법을 확인하세요. 값은 출력하지 않습니다.") from None
    profiles = payload.get("databases")
    if not isinstance(profiles, dict) or not all(isinstance(v, dict) for v in profiles.values()):
        raise MCPError("invalid_oracle_configuration", "[databases.DB_KEY] 접속 블록이 필요합니다.")
    return profiles


def oracle_profile(config_dir: Path, db_key: str) -> dict:
    profiles = read_profiles(config_dir)
    if db_key not in profiles:
        raise MCPError("unknown_db_key", "Catalog의 db_key와 일치하는 Oracle 설정을 추가하세요.", {"db_key": db_key, "file": str(config_dir / "oracle_connections.toml")})
    profile = dict(profiles[db_key])
    if profile.get("password_env"):
        profile["password"] = os.environ.get(str(profile["password_env"]), "")
    missing = [key for key in ("user", "password", "dsn") if not isinstance(profile.get(key), str) or not profile[key].strip()]
    if missing:
        raise MCPError("oracle_configuration_required", "Oracle 접속 정보를 입력하세요.", {"db_key": db_key, "missing": missing, "file": str(config_dir / "oracle_connections.toml")})
    profile["mode"] = str(profile.get("mode", "thin")).lower()
    if profile["mode"] not in {"thin", "thick"}:
        raise MCPError("invalid_oracle_configuration", "Oracle mode는 thin 또는 thick이어야 합니다.")
    timeout = profile.get("connect_timeout_seconds", 10)
    if isinstance(timeout, bool) or not isinstance(timeout, (int, float)) or not 1 <= timeout <= 120:
        raise MCPError("invalid_oracle_configuration", "connect_timeout_seconds는 1~120 범위의 숫자여야 합니다.")
    return profile
