"""Read-only access to the three existing manufacturing metadata collections.

Metadata is evidence for the host model, not executable instructions. No stored
Python or metadata-supplied Mongo query is executed by this module.
"""
from __future__ import annotations

from copy import deepcopy
from datetime import date, datetime
from decimal import Decimal
import json
import re
from typing import Any

from .config import MCPError


KINDS = ("domain", "table_catalog", "main_filter")
_INACTIVE = ("inactive", "disabled", "deleted", "archived", "draft")
_SECRET_FIELDS = {
    "password", "passwd", "pwd", "mongo_uri", "mongodb_uri", "connection_string",
    "api_key", "apikey", "access_token", "api_token", "secret", "client_secret",
    "authorization", "credentials", "username", "user", "dsn", "tns",
}
_CODE_FIELDS = {"python_code", "function_code", "exec_code", "code", "code_string"}
_KEY_FIELDS = {
    "domain": ("key", "payload.key"),
    "table_catalog": ("dataset_key", "key", "payload.dataset_key", "payload.key"),
    "main_filter": ("filter_key", "key", "payload.filter_key", "payload.key"),
}


def _clean(value: Any) -> Any:
    """Keep useful definitions while excluding credentials and executable helpers."""
    if isinstance(value, dict):
        return {
            str(key): _clean(item) for key, item in value.items()
            if str(key).casefold() not in _SECRET_FIELDS | _CODE_FIELDS
        }
    if isinstance(value, (list, tuple)):
        return [_clean(item) for item in value]
    if isinstance(value, (datetime, date)):
        return value.isoformat()
    if isinstance(value, Decimal):
        return str(value)
    if isinstance(value, str):
        return re.sub(r"mongodb(?:\+srv)?://[^\s]+", "[MongoDB connection redacted]", value)
    if value is None or isinstance(value, (bool, int, float)):
        return value
    return str(value)


def _active(document: dict) -> bool:
    body = document.get("payload") if isinstance(document.get("payload"), dict) else {}
    return not any(
        item.get("is_active") is False
        or str(item.get("status") or "").strip().casefold() in _INACTIVE
        for item in (document, body)
    )


def _active_query() -> dict:
    # Legacy records without status remain readable, but explicitly disabled
    # records in either the wrapper or payload never become candidates.
    return {"$and": [
        {"status": {"$nin": list(_INACTIVE)}},
        {"payload.status": {"$nin": list(_INACTIVE)}},
        {"is_active": {"$ne": False}},
        {"payload.is_active": {"$ne": False}},
    ]}


def normalize_document(document: dict, kind: str) -> dict:
    """Normalize wrapped Flow records and older flat records without renaming columns."""
    if kind not in KINDS:
        raise MCPError("invalid_metadata_kind", "kind는 domain, table_catalog, main_filter 중 하나여야 합니다.")
    if not isinstance(document, dict):
        raise MCPError("invalid_metadata_document", "메타데이터 문서가 객체 형식이 아닙니다.")
    body = deepcopy(document.get("payload")) if isinstance(document.get("payload"), dict) else deepcopy(document)
    body.pop("_id", None)
    key_field = {"domain": "key", "table_catalog": "dataset_key", "main_filter": "filter_key"}[kind]
    key = str(document.get(key_field) or document.get("key") or body.get(key_field) or body.get("key") or "").strip()
    section = str(document.get("section") or body.get("section") or "").strip()
    if not key:
        raise MCPError("invalid_metadata_document", "메타데이터의 등록 키가 없습니다.")
    # Some legacy catalog records keep source information on the wrapper.
    for field in ("source_type", "source_config", "required_params", "filter_mappings", "columns", "db_key", "query_template"):
        if field not in body and field in document:
            body[field] = deepcopy(document[field])
    body[key_field] = key
    aliases = []
    for value in (document.get("aliases"), body.get("aliases")):
        for alias in value if isinstance(value, (list, tuple)) else [value]:
            if isinstance(alias, str) and alias.strip() and alias.strip() not in aliases:
                aliases.append(alias.strip())
    display_name = str(body.get("display_name") or document.get("display_name") or key)
    return {
        "kind": kind,
        "key": key,
        "lookup_key": f"{section}:{key}" if kind == "domain" and section else key,
        "section": section,
        "display_name": _clean(display_name),
        "aliases": _clean(aliases),
        "active": _active(document),
        "payload": _clean(body),
    }


def _summary(record: dict) -> dict:
    body = record["payload"]
    result = {key: record[key] for key in ("kind", "key", "lookup_key", "section", "display_name", "aliases")}
    for key in ("description", "summary", "dataset_family", "source_type", "required_params", "selection_criteria", "field", "canonical_column"):
        if key in body:
            value = body[key]
            result[key] = value[:700] if isinstance(value, str) else value
    return result


def _contains(text: str, term: str) -> bool:
    if not term:
        return False
    before = r"(?<![a-z0-9_])" if term[0].isascii() and term[0].isalnum() else ""
    after = r"(?![a-z0-9_])" if term[-1].isascii() and term[-1].isalnum() else ""
    return bool(re.search(before + re.escape(term) + after, text, flags=re.IGNORECASE))


def _score(record: dict, query: str) -> int:
    if not query:
        return 1
    names = [record["key"], record["display_name"], *record["aliases"]]
    score = sum(30 if name.casefold() == query.casefold() else 10 for name in names if _contains(query, name))
    # Search definitions too, but never search SQL or stored Python code.
    searchable = _summary(record)
    body = record["payload"]
    for field in ("processes", "terms", "usage_rule", "keywords", "column_candidates", "meaning", "source_datasets"):
        if field in body:
            searchable[field] = body[field]
    text = json.dumps(searchable, ensure_ascii=False, default=str)
    return score + sum(1 for term in re.findall(r"[\w/.-]+", query) if _contains(text, term))


class MetadataRepository:
    def __init__(self, settings: Any, client_factory: Any = None):
        self.settings = settings
        self.client_factory = client_factory

    def _client(self):
        if not self.settings.mongo_uri or not self.settings.mongo_database:
            raise MCPError("configuration_required", ".env에 MONGODB_URI와 MONGODB_DATABASE를 입력하세요.")
        if not all(self.settings.collections.get(kind) for kind in KINDS):
            raise MCPError("configuration_required", ".env에 domain, table_catalog, main_filter 컬렉션 이름을 모두 입력하세요.")
        factory = self.client_factory
        if factory is None:
            from pymongo import MongoClient
            factory = MongoClient
        timeout = self.settings.mongo_timeout_ms
        return factory(self.settings.mongo_uri, serverSelectionTimeoutMS=timeout,
                       connectTimeoutMS=timeout, socketTimeoutMS=timeout, appname="manufacturing-oracle-mcp")

    def _read(self, kind: str, query: dict) -> tuple[list[dict], bool]:
        client = None
        try:
            client = self._client()
            collection = client[self.settings.mongo_database][self.settings.collections[kind]]
            cursor = collection.find({"$and": [_active_query(), query]})
            cursor = cursor.sort("_id", 1).limit(self.settings.metadata_limit + 1).max_time_ms(self.settings.mongo_timeout_ms)
            documents = list(cursor)
            truncated = len(documents) > self.settings.metadata_limit
            records = []
            for document in documents[:self.settings.metadata_limit]:
                # Ignore structurally unrelated collection documents, not an
                # unavailable database or an invalid requested catalog record.
                try:
                    record = normalize_document(document, kind)
                except MCPError:
                    continue
                if record["active"]:
                    records.append(record)
            return records, truncated
        except MCPError:
            raise
        except Exception:
            raise MCPError("metadata_connection_failed", "MongoDB 메타데이터를 읽지 못했습니다. 연결 URI, DB와 컬렉션 이름, 읽기 권한을 확인하세요.") from None
        finally:
            if client is not None:
                client.close()

    def search(self, query: str = "", kind: str = "all", limit: int = 20, offset: int = 0) -> dict:
        if kind not in (*KINDS, "all"):
            raise MCPError("invalid_metadata_kind", "kind는 all, domain, table_catalog, main_filter 중 하나여야 합니다.")
        if not isinstance(query, str) or len(query) > 2000 or not 1 <= limit <= 100 or offset < 0:
            raise MCPError("invalid_search", "검색어는 2000자 이하, limit은 1~100, offset은 0 이상이어야 합니다.")
        scored, capped = [], []
        for current_kind in KINDS if kind == "all" else (kind,):
            records, truncated = self._read(current_kind, {})
            if truncated:
                capped.append(current_kind)
            for record in records:
                score = _score(record, query.strip())
                if score:
                    scored.append((score, record))
        scored.sort(key=lambda pair: (-pair[0], pair[1]["kind"], pair[1]["lookup_key"].casefold()))
        page = scored[offset:offset + limit]
        has_more = offset + limit < len(scored)
        return {
            "items": [_summary(record) for _, record in page],
            "matched_count": len(scored), "offset": offset,
            "next_offset": offset + limit if has_more else None,
            "scan_truncated": bool(capped), "truncated_collections": capped,
            "warnings": ["메타데이터 읽기 한도에 도달했습니다. 전체 목록이 아닙니다. 등록 키를 알면 get_metadata로 직접 조회하거나 METADATA_SCAN_LIMIT을 늘리세요."] if capped else [],
        }

    def get(self, kind: str, key: str) -> dict:
        if kind not in KINDS or not isinstance(key, str) or not key.strip() or len(key) > 300:
            raise MCPError("invalid_metadata_key", "종류와 300자 이하의 등록 키를 지정하세요.")
        lookup = key.strip()
        section = ""
        if kind == "domain" and ":" in lookup:
            section, lookup = lookup.split(":", 1)
        fields = _KEY_FIELDS[kind]
        for case_sensitive in (True, False):
            comparison: Any = lookup if case_sensitive else {"$regex": "^" + re.escape(lookup) + "$", "$options": "i"}
            query: dict = {"$or": [{field: comparison} for field in fields]}
            if section:
                query = {"$and": [query, {"$or": [{"section": section}, {"payload.section": section}]}]}
            records, truncated = self._read(kind, query)
            matches = [record for record in records if
                       (record["key"] == lookup if case_sensitive else record["key"].casefold() == lookup.casefold())
                       and (not section or record["section"] == section)]
            if matches or truncated:
                return self._unique(matches, truncated)
        # Explicit aliases are useful for discovery, but an actual registered
        # key always wins over an overlapping alias from another record.
        comparison = {"$regex": "^" + re.escape(lookup) + "$", "$options": "i"}
        alias_fields = ("aliases", "payload.aliases", "display_name", "payload.display_name")
        records, truncated = self._read(kind, {"$or": [{field: comparison} for field in alias_fields]})
        matches = [record for record in records if
                   any(name.casefold() == lookup.casefold() for name in [record["display_name"], *record["aliases"]])
                   and (not section or record["section"] == section)]
        if matches or truncated:
            return self._unique(matches, truncated)
        raise MCPError("metadata_not_found", f"활성 {kind} 항목을 찾지 못했습니다. search_metadata로 등록 키를 확인하세요.")

    @staticmethod
    def _unique(records: list[dict], truncated: bool) -> dict:
        # Identical duplicate documents are harmless; differing definitions
        # with the same key must not select a random connection or query.
        unique = {json.dumps(record, ensure_ascii=False, sort_keys=True, default=str): record for record in records}
        if len(unique) == 1 and not truncated:
            return next(iter(unique.values()))
        raise MCPError("ambiguous_metadata", "동일 표현에 여러 활성 정의가 있습니다. 검색 결과의 lookup_key로 항목을 지정하세요.",
                       {"candidates": [_summary(record) for record in list(unique.values())[:20]], "scan_truncated": truncated})

    def status(self) -> dict:
        client = None
        try:
            client = self._client()
            database = client[self.settings.mongo_database]
            counts = {kind: database[self.settings.collections[kind]].count_documents(_active_query(), maxTimeMS=self.settings.mongo_timeout_ms)
                      for kind in KINDS}
            return {"status": "ok", "active_documents": counts, "read_only": True}
        except MCPError:
            raise
        except Exception:
            raise MCPError("metadata_connection_failed", "MongoDB 상태 확인에 실패했습니다. 연결 설정과 읽기 권한을 확인하세요.") from None
        finally:
            if client is not None:
                client.close()
