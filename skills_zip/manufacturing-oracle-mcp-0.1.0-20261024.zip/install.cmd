@echo off
setlocal
where python >nul 2>nul
if errorlevel 1 (
  echo Python 3.11 or newer is required. Install Python and run install.cmd again.
  exit /b 2
)
python -X utf8 -B "%~dp0install.py" %*
exit /b %errorlevel%
