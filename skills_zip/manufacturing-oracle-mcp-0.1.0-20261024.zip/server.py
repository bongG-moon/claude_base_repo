"""Portable entrypoint referenced by Claude Code's MCP configuration."""
from oracle_metadata_mcp.server import main

if __name__ == "__main__":
    raise SystemExit(main())
