# 검증 기록

검증일: 2026-10-24 (KST)

## 검증 환경

- Windows, Python 3.13.5
- MCP Python SDK 1.28.1, pymongo 4.17.0, python-oracledb 3.3.0, sqlglot 28.5.0, python-dotenv 1.2.2
- 새 MCP 패키지는 Langflow 런타임에 의존하지 않습니다. 기존 Flow Python 및 import-ready JSON은 변경하지 않았습니다.

## 검증 결과

- 전체 회귀 테스트: **117 passed, 4 skipped** (13.52초)
- 건너뛴 4건: 현재 Windows 계정에 symlink 생성 권한이 없어 관련 설치 경로 테스트만 생략
- 실제 배포 ZIP을 한글/공백이 있는 별도 임시 프로젝트에 설치하고 재설치: 설정 2개 바이트 보존 확인
- 압축본에서 설치한 진입점으로 실제 MCP initialize, 도구 6개 목록, 미설정 상태 응답 확인
- ZIP 구성: 플랫폼 배포 도우미로 검증. 실행 코드, 설치기, 설명서와 빈 설정 템플릿만 포함
- 의존성 다운로드와 운영 Claude 설정 변경은 수행하지 않음. 압축본 설치 검증은 `--skip-dependencies`와 현재 검증 런타임으로 수행

개발용 결과 기록은 `.tmp/mcp-release-results.xml`에 있습니다. 패키지 검증은 `tools/validate_local_oracle_mcp_package.py <ZIP 경로>`로 재실행할 수 있습니다.

## 검증한 항목

- 실제 Flow의 Mongo 문서 형태: Domain section/key/payload, Catalog dataset_key/payload, Main Filter filter_key/payload
- 설정 파일 자동 생성, 한국어/공백 경로, 재설치 시 기존 접속 설정 보존
- 프로젝트/사용자 범위 선택, 빈 입력/취소, 다른 MCP 보존, 등록 오류 안내
- Oracle 필수 파라미터와 조회 후 필터 분리, bind와 SQL injection 문자열 처리
- SELECT/CTE/서브쿼리/UNION, Oracle q 문자열, 끝 주석, 위험한 다중문/변경/행잠금 거절
- 숫자/문자 필터, canonical/physical 컬럼 매핑, 결과 잘림 표시, 0건과 실패 구분
- 원본 조회 결과 JSONL/CSV 저장 및 read_result 페이징, 비밀정보 비노출
- 실제 stdio child process에서 initialize, tools/list, tools/call과 구조화 응답

MongoDB와 Oracle의 네트워크 연결 부분은 격리된 fake로 검증했습니다. stdio 통신은 실제 MCP SDK 클라이언트와 서버 프로세스를 사용했습니다. Windows sandbox가 이벤트 루프의 socketpair를 제한하여 해당 통신 검증은 승인된 별도 실행 환경에서 진행했습니다.

실제 사내 MongoDB/Oracle 연결, 데이터 정확도, 설치 PC의 사내 pip 저장소 다운로드, 사용자 Claude Code 대화 실행은 사용자 설정 후 확인해야 합니다. Oracle 읽기 전용 계정이 필요합니다. 이 검증은 운영 권한이나 네트워크 접근을 대신 보장하지 않습니다.

## 기존 Flow 확인 범위

기존 Flow는 수정하지 않았습니다. 저장소 공통 `validate_flow_component_sources.py`를 별도로 실행했을 때 기존 Table Catalog Flow의 Normalizer/Writer/Response 3개 노드에서 원본-JSON 불일치가 보고됐습니다(3개 export 형태에 반복). rev_2는 통과했습니다. 해당 기존 파일은 이번 변경 대상이 아니므로 재생성하거나 수정하지 않았으며, 새 로컬 MCP 검증 결과와 구분합니다.

## 재실행

저장소 개발 환경에서 다음을 실행합니다. pytest는 배포 실행 의존성에 포함하지 않습니다.

```powershell
python -X utf8 -B -m pytest -c local_oracle_mcp/pytest.ini local_oracle_mcp/tests
```

설치 후 실제 연결은 Claude Code의 `configuration_status(check_mongodb=true)`와 `check_oracle_connection(db_key)`로 각각 확인합니다.
