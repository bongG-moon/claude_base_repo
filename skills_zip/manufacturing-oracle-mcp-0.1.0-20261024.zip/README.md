# 제조 메타데이터 Oracle MCP

Claude Code에서 기존 제조 Domain, Table Catalog, Main Flow Filter를 읽고 등록된 Oracle 데이터를 조회하는 로컬 MCP입니다. 질문 해석, 후속 대화와 집계/비교는 Claude Code가 수행합니다. 이 패키지는 Langflow 서버나 별도 LLM API Key 없이 stdio 프로세스로 실행됩니다.

## 설치

Python 3.11 이상과 Claude Code, MongoDB 메타데이터 읽기 권한, Oracle 조회 권한이 필요합니다. Windows/Python 3.13에서 검증했습니다. 기본 Oracle thin 모드는 Instant Client가 필요 없으며 구형 DB 등 thick 모드가 필요하면 해당 Client를 사용자가 준비합니다.

ZIP 전체를 푼 뒤 `install.cmd`를 실행하고 **프로젝트 / 내 계정 전체** 중 설치 범위를 선택하세요. 기본 선택은 없습니다. Python 실행 파일을 찾지 못하면 설치된 Python으로 `install.py`를 실행하세요. 프로젝트 설치는 ZIP 폴더가 아니라 사용할 작업 폴더를 명시하는 것이 편합니다.

```powershell
# 현재 프로젝트에 설치: C:\work\analysis는 미리 존재하는 작업 폴더로 바꾸세요.
python "압축해제경로\install.py" --scope project --project-dir "C:\work\analysis"

# 내 계정 전체에서 사용
python "압축해제경로\install.py" --scope user
```

범위 선택 후 설치 대상 경로를 표시하고, 전용 가상환경에 requirements.txt의 패키지를 설치합니다. 사용자 전체 설치는 관리자 권한을 요구하지 않습니다. 회사망에서는 사내 pip 저장소를 먼저 설정하세요. 인증서 검사를 해제하거나 인터넷 저장소로 자동 우회하지 않습니다. 다운로드가 불가능하면 동일 버전의 wheel 및 전이 의존성을 준비하고 pip의 `PIP_NO_INDEX`/`PIP_FIND_LINKS`로 지정할 수 있습니다.

설치가 끝나면 **작성할 두 파일의 절대 경로**가 표시됩니다.

| 파일 | 입력 내용 |
| --- | --- |
| `<설치위치>\config\.env` | MongoDB 연결 URI, DB명, 공통 Filter/Catalog/Domain 컬렉션명 |
| `<설치위치>\config\oracle_connections.toml` | Oracle db_key별 사용자, 비밀번호, DSN, thin/thick 모드 |

프로젝트 설치 위치는 `<작업폴더>\.manufacturing-oracle-mcp`, 사용자 설치 위치는 `<사용자 홈>\.manufacturing-oracle-mcp`입니다. 두 파일에 항목별 설명과 예시가 주석으로 들어 있습니다. 실제 비밀번호는 이 로컬 파일에서만 입력하세요. 재설치해도 작성한 설정을 덮어쓰지 않습니다.

`.env`의 MongoDB 주소는 기존 Flow에서 사용하는 `mongodb://...` 또는 `mongodb+srv://...` 연결 URI입니다. HTTP Mongo API나 P&T AI SQUARE의 개인 KEY가 아닙니다. 세 컬렉션은 같은 DB에 존재하는 기존 컬렉션 이름을 입력하며, 새 컬렉션이나 세션 저장소를 만들지 않습니다.

Oracle 설정의 `[databases.PNT_RPT]`는 Catalog의 `source_config.db_key = "PNT_RPT"`와 연결됩니다. 다른 DB가 있으면 해당 키로 블록을 추가합니다. `password_env`를 지정하면 프로세스 환경변수에서 비밀번호를 읽습니다. 한 MCP 프로세스에서는 thin/thick 모드를 혼용하지 마세요.

## Claude Code 연결과 첫 확인

프로젝트 설치는 `.mcp.json`에 `manufacturing-oracle` 항목을 추가하고 다른 MCP 항목을 보존합니다. 기존 파일은 설치 폴더의 backups에 보관합니다. 사용자 설치는 공식 `claude mcp add-json --scope user` 명령을 사용합니다. 동일 이름의 다른 등록이 있거나 CLI를 찾지 못하면 기존 항목을 건드리지 않고 수동 연결 안내를 출력합니다.

설정 작성 후 Claude Code를 다시 열어 `/mcp`에서 연결을 확인하고 프로젝트 MCP 사용을 승인하세요. 이후 아래처럼 요청할 수 있습니다.

> manufacturing-oracle 설정 상태를 확인하고 MongoDB 메타데이터 읽기와 PNT_RPT Oracle 연결을 각각 점검해줘.

> 오늘 DA공정 생산량을 알려줘. 먼저 등록된 공정 정의와 오늘 생산량 Catalog를 확인해줘.

> WB공정은?

> SBM공정 제품별 보유CAPA를 계산해줘. 등록된 계산 순서와 조인 기준을 확인한 뒤 필요한 Oracle 데이터를 조회해줘.

설정값이 비어 있어도 MCP 자체는 시작합니다. 도구에서 빠진 항목과 파일 위치를 알려줍니다. 미설정/접속 실패를 0건이나 더미 결과로 표시하지 않습니다. `configuration_status`의 configured는 파일 입력 상태이며 실제 연결 성공을 뜻하지 않습니다. Mongo는 `check_mongodb=true`, Oracle은 `check_oracle_connection(db_key)`로 별도 확인합니다.

수동 설정은 `<설치위치>\claude-mcp.json`을 참고하세요. 포함된 command/args는 절대 경로이며 비밀번호나 URI가 들어 있지 않습니다. `--no-register`를 붙이면 파일과 가상환경만 준비합니다. `--skip-dependencies`는 오프라인 파일 준비용으로 실행환경 검증과 자동 등록을 생략하므로, 실제 사용 전에 일반 설치를 다시 실행해야 합니다.

## 제공 도구와 분석 흐름

| 도구 | 역할 |
| --- | --- |
| configuration_status | 설정 파일 위치, 누락 값, 현재 한국 시각과 선택적 Mongo 읽기 점검 |
| search_metadata | 3개 컬렉션의 활성 metadata 후보 검색 및 목록 페이징 |
| get_metadata | 선택한 Domain/Catalog/Filter의 실제 정의 읽기 |
| check_oracle_connection | 등록 DB 프로필에서 SELECT 1 FROM DUAL 연결 점검 |
| query_dataset | Catalog에 저장된 SQL과 필수 파라미터로 Oracle 조회, 표준 필터 적용 |
| read_result | 저장한 조회 결과를 최대 200행씩 읽기 |

조회 조건은 구분해서 전달합니다. 예를 들어 `parameters={"DATE":"20261024"}`는 원본 조회에 필요한 bind이고, `filters={"OPER_NAME":{"operator":"in","value":["D/A1","D/A2"]},"LEAD":{"operator":"eq","value":78}}`는 조회 후 필터입니다. 실제 공정 범위와 날짜 형식은 조회한 메타데이터에서 확인해야 합니다. MCP가 특정 제품명이나 공정명을 하드코딩하지 않습니다.

기존 Flow의 `{DATE}`, `'{DATE}'` 템플릿과 Oracle `:DATE` bind를 지원합니다. 값은 SQL 문자열에 직접 삽입하지 않습니다. 등록된 SELECT/CTE 조회만 실행하며 SQL 작성 도구나 Mongo/Oracle 쓰기 도구는 제공하지 않습니다. DB 함수가 포함된 SELECT의 권한까지 문자열 검사로 보장할 수는 없으므로 실제 Oracle 계정도 조회 전용 권한으로 구성하세요.

Catalog의 `filter_mappings`에 따라 원본 컬럼을 보존하고 표준 컬럼을 추가합니다. 반환되는 `column_mapping`을 확인해 동일 값을 중복 집계하지 마세요. 숫자 파라미터와 문자열로 저장된 LEAD 등의 비교를 지원하고, 없는 컬럼이나 미지원 조건은 이유를 반환합니다. Domain에 등록된 Python helper는 실행하지 않으며 호스트가 등록된 업무 의미를 참고합니다.

## 결과와 후속 질문

조회 결과는 `<설치위치>\results\<result_id>`에 JSONL, CSV, 조회 조건을 기록한 metadata.json으로 저장합니다. 도구 응답은 미리보기와 전체 파일 경로를 반환합니다. Claude Code는 JSONL 전체를 읽어 집계/조인하거나 `read_result`로 나머지 행을 확인할 수 있습니다. CSV는 원본 값 보존용이므로 Excel에서 열 때 데이터 가져오기 기능을 사용하고 수식으로 해석될 수 있는 외부 문자열에 유의하세요.

기본 원본 한도는 50,000행입니다. 초과하면 `truncated=true`, `complete=false`를 표시합니다. 필터가 조회 후 적용되므로 한도 안에 해당 제품이 없다는 이유만으로 전체 원본도 0건이라고 판단하면 안 됩니다. 전체 집계를 하려면 원본 조회 조건을 줄이거나 `.env`의 한도를 조정해 재조회하세요. 셀 값 잘림 및 파일 저장 실패도 숨기지 않습니다.

대화 이력은 Claude Code가 관리합니다. 필수 DATE/LOT_ID/EQP_ID가 바뀌면 재조회하고, 필터 변경은 이전 데이터가 새 범위를 포함할 때만 재사용하도록 서버 지침에 명시했습니다. 결과 파일은 대화 세션 저장소가 아닌 조회 스냅샷이며 현재 DB 상태를 자동 반영하지 않습니다. 범위가 모호하거나 파일이 없으면 다시 조회합니다. 이전 Flow의 세션 로더, LLM 의도분석기, pandas 실행기, HTML Report 서버는 이 1차 MCP에 포함하지 않습니다.

로컬 결과에는 업무 데이터가 포함됩니다. 자동 삭제는 하지 않으므로 사용을 마친 results 하위 결과 폴더는 회사 보존 기준에 맞춰 정리하세요. 로컬 접속 설정과 결과 파일은 Git이나 배포 ZIP에 포함하지 마세요.

## 업데이트와 제거

새 ZIP의 설치기를 같은 범위로 다시 실행하면 기존 접속 설정을 보존하고 이전 app을 백업합니다. 의존성 버전이 달라진 경우 기존 환경을 자동 변경하지 않고 안내합니다. MCP를 종료하고 기존 `.venv`를 다른 이름으로 보관한 뒤 다시 설치할 수 있습니다. 플랫폼의 새 버전 게시가 PC 파일을 자동 교체하지는 않습니다. 자동 버전 확인 및 자동 업데이트는 이번 패키지에 포함하지 않았습니다.

제거 시 Claude Code에서 해당 범위의 `manufacturing-oracle` 등록만 제거하세요. 프로젝트 범위는 `.mcp.json`의 해당 항목만 삭제하고 다른 MCP를 보존합니다. 이후 필요한 설정/결과를 보관하고 이 도구의 `.manufacturing-oracle-mcp` 폴더를 삭제합니다.

## 검증 범위와 플랫폼 등록

설정 생성/재설치, metadata 실제 문서 형태, 필수 조건과 필터 분리, bind, SELECT/CTE, 결과 페이징, 오류/잘림, MCP initialize/tools 호출을 격리된 fixture로 검증합니다. 실제 사내 MongoDB/Oracle 접속과 사용자의 Claude 대화는 계정 입력 후 확인해야 합니다. 검증 상세는 VALIDATION.md에 기록합니다.

P&T AI SQUARE의 파일 배포 형식에 맞춘 ai-square.json이 포함됩니다. 유형은 MCP/Tool, 사용 프로그램은 Claude입니다. 조직, 담당자, 조회 공개 범위는 플랫폼 등록 시 선택하세요. 게시와 자동 업데이트는 설치와 별개입니다.

공식 참고: [Claude Code MCP 연결](https://code.claude.com/docs/en/mcp), [검증한 MCP Python SDK v1.28.1](https://github.com/modelcontextprotocol/python-sdk/tree/v1.28.1), [Oracle bind 변수](https://python-oracledb.readthedocs.io/en/v3.3.0/user_guide/bind.html).
