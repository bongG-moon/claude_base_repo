"""Install the local Oracle MCP without replacing other Claude settings.

Python 3.11+ and standard library only. Scope selection happens before any write.
Actual DB connections and credentials are deliberately not used by this installer.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path

from install_scope import select_scope


SERVER_NAME = "manufacturing-oracle"
INSTALL_DIR = ".manufacturing-oracle-mcp"
REQUIRED_FILES = ("server.py", "requirements.txt", "env.example", "oracle_connections.example.toml")


class InstallError(ValueError):
    """A user-actionable installation failure; never contains secret values."""


def _rename_directory(source: Path, destination: Path) -> None:
    """Briefly retry Windows scan/share locks, but never other rename failures."""
    for attempt in range(5):
        try:
            source.rename(destination)
            return
        except PermissionError as exc:
            if getattr(exc, "winerror", None) not in {5, 32, 33} or attempt == 4:
                raise
            time.sleep(0.1 * (attempt + 1))


def _read_object(path: Path) -> dict:
    try:
        value = json.loads(path.read_text(encoding="utf-8-sig"))
    except (OSError, ValueError) as exc:
        raise InstallError(f"JSON 설정을 읽을 수 없습니다: {path}. 기존 파일은 그대로 보존합니다.") from exc
    if not isinstance(value, dict):
        raise InstallError(f"JSON 최상위 값이 object가 아닙니다: {path}")
    return value


def _atomic_json(path: Path, value: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, name = tempfile.mkstemp(prefix=f".{path.name}.", suffix=".tmp", dir=path.parent)
    tmp = Path(name)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8", newline="\n") as handle:
            json.dump(value, handle, ensure_ascii=False, indent=2)
            handle.write("\n")
        os.replace(tmp, path)
    finally:
        if tmp.exists():
            tmp.unlink()


def _project_config(path: Path, entry: dict, previous_entry: dict | None) -> tuple[dict, bytes | None]:
    if path.is_symlink() or (path.exists() and path.resolve() != path):
        raise InstallError(f"Claude 설정이 외부 경로로 연결되어 있습니다: {path}. 원본을 확인한 뒤 수동 연결하세요.")
    original = path.read_bytes() if path.exists() else None
    config = _read_object(path) if original is not None else {}
    servers = config.setdefault("mcpServers", {})
    if not isinstance(servers, dict):
        raise InstallError(f"{path}의 mcpServers는 object여야 합니다. 파일을 변경하지 않았습니다.")
    old = servers.get(SERVER_NAME)
    if old is not None and old != entry and old != previous_entry:
        raise InstallError(
            f"{path}에 다른 {SERVER_NAME} 설정이 있습니다. 기존 설정을 확인한 뒤 별도로 정리하세요. 덮어쓰지 않았습니다."
        )
    servers[SERVER_NAME] = entry
    return config, original


def _run(command: list[str], *, runner, cwd: Path, timeout: int = 600):
    try:
        return runner(command, cwd=str(cwd), capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=timeout)
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise InstallError("설치 명령을 시작하지 못했거나 제한 시간을 초과했습니다. Python/Claude 실행 경로를 확인하세요.") from exc


def _verify_runtime(python: Path, requirements: Path, *, runner, cwd: Path) -> bool:
    # Requirements are pinned by this package. Compare distribution versions
    # rather than importing a server that might connect to business databases.
    code = (
        "import importlib.metadata as m,re,sys;"
        "text=open(sys.argv[1],encoding='utf-8-sig').read();"
        "pins=re.findall(r'^\\s*([A-Za-z0-9_.-]+)==([^\\s;#]+)',text,re.M);"
        "assert pins, 'no pinned requirements';"
        "assert all(m.version(n)==v for n,v in pins), 'dependency mismatch'"
    )
    result = _run([str(python), "-I", "-c", code, str(requirements)], runner=runner, cwd=cwd, timeout=30)
    return result.returncode == 0


def _prepare_runtime(target: Path, source: Path, *, runner) -> Path:
    runtime = target / ".venv"
    python = runtime / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
    if python.is_file():
        if not _verify_runtime(python, source / "requirements.txt", runner=runner, cwd=target):
            raise InstallError(
                f"기존 실행환경의 패키지 버전이 이번 배포와 다릅니다: {runtime}. "
                "기존 app과 접속 설정은 보존했습니다. MCP를 종료하고 .venv를 별도 이름으로 보관한 뒤 다시 설치하세요."
            )
        return python
    if runtime.exists():
        raise InstallError(f"완성되지 않은 실행환경이 있습니다: {runtime}. 확인 후 별도 이름으로 보관하고 다시 설치하세요.")
    created = _run([sys.executable, "-m", "venv", str(runtime)], runner=runner, cwd=target)
    if created.returncode:
        raise InstallError(f"가상환경 생성에 실패했습니다: {runtime}. Python의 venv 지원을 확인하세요.")
    install = _run(
        [str(python), "-m", "pip", "install", "--disable-pip-version-check", "-r", str(source / "requirements.txt")],
        runner=runner, cwd=target,
    )
    if install.returncode:
        raise InstallError(
            f"의존성 설치에 실패했습니다: {runtime}. 사내 패키지 저장소/망 연결을 확인하세요. "
            "기존 app과 Claude 설정은 변경하지 않았습니다. .venv를 보관한 뒤 다시 설치하거나 안내된 requirements.txt를 설치하세요."
        )
    if not _verify_runtime(python, source / "requirements.txt", runner=runner, cwd=target):
        raise InstallError("의존성 버전 검증에 실패했습니다. Claude 설정은 변경하지 않았습니다.")
    return python


def _copy_app(source: Path, destination: Path) -> None:
    destination.mkdir()
    for name in REQUIRED_FILES:
        shutil.copy2(source / name, destination / name)
    for name in ("README.md", "ai-square.json"):
        if (source / name).is_file():
            shutil.copy2(source / name, destination / name)
    shutil.copytree(
        source / "oracle_metadata_mcp", destination / "oracle_metadata_mcp",
        ignore=shutil.ignore_patterns("__pycache__", "*.pyc", "*.pyo", ".env", "*.log"),
    )


def _init_private_config(target: Path, source: Path) -> Path:
    config_dir = target / "config"
    config_dir.mkdir(exist_ok=True)
    for template, name in (("env.example", ".env"), ("oracle_connections.example.toml", "oracle_connections.toml")):
        path = config_dir / name
        try:
            with path.open("xb") as handle:
                handle.write((source / template).read_bytes())
            if os.name != "nt":
                path.chmod(0o600)
        except FileExistsError:
            pass  # Never replace user settings, even when installing again.
    return config_dir


def _claude_command(which) -> list[str] | None:
    """Avoid cmd.exe reinterpreting JSON and paths passed through an npm shim."""
    claude = which("claude")
    if not claude:
        return None
    shim = Path(claude)
    if shim.suffix.lower() not in {".cmd", ".bat", ".ps1"}:
        return [claude]
    # npm's official Windows shims point to one of these two package entrypoints.
    # Calling the actual executable with argv avoids nested cmd quoting and %/& expansion.
    package = shim.parent / "node_modules" / "@anthropic-ai" / "claude-code"
    executable = package / "bin" / "claude.exe"
    if executable.is_file():
        return [str(executable)]
    script = package / "cli.js"
    node = shim.parent / "node.exe"
    node_command = str(node) if node.is_file() else which("node")
    if script.is_file() and node_command and Path(node_command).suffix.lower() not in {".cmd", ".bat", ".ps1"}:
        return [node_command, str(script)]
    # Do not execute an unknown batch shim with credentials/configuration in argv.
    return None


def _register_user(entry: dict, *, runner, which, cwd: Path) -> tuple[str, list[str]]:
    claude = _claude_command(which)
    if not claude:
        return "manual_registration_required", ["직접 실행 가능한 Claude CLI를 찾지 못했습니다. claude-mcp.json의 설정으로 수동 연결하세요."]
    exists = _run([*claude, "mcp", "get", SERVER_NAME], runner=runner, cwd=cwd, timeout=30)
    if exists.returncode == 0:
        # get has no stable machine-readable schema across Claude versions.
        # Never delete/replace a server based on parsing human-facing output.
        return "existing_registration_preserved", [
            f"이미 {SERVER_NAME} 항목이 있어 등록 설정은 변경하지 않았습니다. claude mcp get {SERVER_NAME}으로 경로를 확인하세요."
        ]
    result = _run(
        [*claude, "mcp", "add-json", "--scope", "user", SERVER_NAME, json.dumps(entry, ensure_ascii=False)],
        runner=runner, cwd=cwd, timeout=30,
    )
    if result.returncode:
        return "manual_registration_required", ["Claude 사용자 범위 등록에 실패했습니다. 기존 MCP는 보존되며 claude-mcp.json으로 수동 연결할 수 있습니다."]
    return "registered", []


def install(
    source: Path, selection: dict, *, skip_dependencies: bool = False,
    register: bool = True, runner=subprocess.run, which=shutil.which,
) -> dict:
    """Install only into the explicitly selected base; useful for isolated tests."""
    scope = selection.get("scope")
    if scope not in {"project", "user"}:
        raise InstallError("명시적인 project 또는 user 범위가 필요합니다.")
    source = Path(source).resolve()
    base = Path(selection["baseDirectory"]).resolve()
    if not base.is_dir():
        raise InstallError("설치 기준 디렉토리가 없습니다.")
    target = base / INSTALL_DIR
    if target.is_symlink() or (target.exists() and target.resolve() != target):
        raise InstallError("설치 대상이 외부 경로로 연결되어 있습니다. 일반 디렉토리를 사용하세요.")
    missing = [name for name in REQUIRED_FILES if not (source / name).is_file()]
    if missing or not (source / "oracle_metadata_mcp").is_dir():
        raise InstallError("배포 파일이 누락되었습니다. ZIP 전체를 다시 풀어주세요.")
    for relative in (
        "app", "config", ".venv", "config/.env", "config/oracle_connections.toml",
        "install-state.json", "claude-mcp.json", ".gitignore", "backups",
    ):
        protected = target / relative
        if protected.is_symlink() or (protected.exists() and protected.resolve() != protected):
            raise InstallError(f"설치 대상에 외부 연결 경로가 있습니다: {protected}")
    state_path = target / "install-state.json"
    old_state = _read_object(state_path) if state_path.exists() else {}
    if target.exists() and not old_state:
        raise InstallError(f"기존 디렉토리의 소유 여부를 확인할 수 없습니다: {target}. 별도 이름으로 보관한 뒤 설치하세요.")
    if old_state and old_state.get("package") != SERVER_NAME:
        raise InstallError("다른 도구가 사용하는 설치 폴더입니다. 변경하지 않았습니다.")
    venv_python = target / ".venv" / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
    python = venv_python if not skip_dependencies or venv_python.is_file() else Path(sys.executable).resolve()
    config_dir = target / "config"
    entry = {"type": "stdio", "command": str(python), "args": ["-B", str(target / "app" / "server.py"), "--config-dir", str(config_dir)]}
    project_file = base / ".mcp.json"
    project_config = original_config = None
    if scope == "project" and register and not skip_dependencies:
        project_config, original_config = _project_config(project_file, entry, old_state.get("entry"))
    print(f"설치 범위: {scope}\n설치 위치: {target}\n설정 위치: {config_dir}", flush=True)
    target.mkdir(exist_ok=True)
    if not state_path.exists():
        _atomic_json(state_path, {"package": SERVER_NAME, "scope": scope, "status": "preparing"})
    ignore = target / ".gitignore"
    if not ignore.exists():
        ignore.write_text("*\n", encoding="utf-8")
    _init_private_config(target, source)
    if not skip_dependencies:
        _prepare_runtime(target, source, runner=runner)
    stage = target / f"app-stage-{uuid.uuid4().hex}"
    _copy_app(source, stage)
    backup = None
    app = target / "app"
    old_app_moved = False
    # Retain the previous app as a recoverable backup, never recursively delete it.
    try:
        if app.exists():
            backup = target / f"app-backup-{datetime.now(timezone.utc):%Y%m%dT%H%M%S}-{uuid.uuid4().hex[:6]}"
            _rename_directory(app, backup)
            old_app_moved = True
        _rename_directory(stage, app)
    except OSError as exc:
        if old_app_moved:
            try:
                _rename_directory(backup, app)
            except OSError as rollback_exc:
                raise InstallError(
                    f"앱 교체 및 이전 앱 복원에 실패했습니다. 이전 파일은 {backup}에 보존되어 있습니다. "
                    "MCP를 종료하고 이 폴더를 app으로 복원하세요. Claude 설정은 변경하지 않았습니다."
                ) from rollback_exc
        raise InstallError("앱 파일 교체에 실패했습니다. 기존 앱과 Claude 설정을 보존했습니다. MCP를 종료한 뒤 다시 설치하세요.") from exc
    warnings = []
    registration = "not_requested"
    snippet = target / "claude-mcp.json"
    _atomic_json(snippet, {"mcpServers": {SERVER_NAME: entry}})
    if skip_dependencies:
        registration = "dependency_unverified"
        warnings.append("의존성 검증을 생략했으므로 Claude에 자동 등록하지 않았습니다. 설정 작성 후 일반 설치를 다시 실행하세요.")
    elif register and scope == "project":
        current = project_file.read_bytes() if project_file.exists() else None
        if current != original_config:
            registration = "manual_registration_required"
            warnings.append("설치 중 .mcp.json이 변경되어 자동 연결을 생략했습니다. 다른 작업의 변경은 보존했습니다.")
        else:
            if original_config is not None:
                backup_dir = target / "backups"
                backup_dir.mkdir(exist_ok=True)
                (backup_dir / f"mcp-{uuid.uuid4().hex}.json").write_bytes(original_config)
            _atomic_json(project_file, project_config)
            registration = "registered"
    elif register:
        registration, warnings = _register_user(entry, runner=runner, which=which, cwd=base)
    result = {
        "package": SERVER_NAME, "scope": scope,
        "status": "dependency_unverified" if skip_dependencies else "configuration_required",
        "registration": registration, "install_dir": str(target),
        "env_file": str(config_dir / ".env"),
        "oracle_config": str(config_dir / "oracle_connections.toml"),
        "mcp_config": str(snippet), "entry": entry,
        "requirements_sha256": hashlib.sha256((source / "requirements.txt").read_bytes()).hexdigest(),
        "app_backup": str(backup) if backup else None, "warnings": warnings,
    }
    _atomic_json(state_path, result)
    return result


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="제조 Oracle MCP 설치: 범위를 선택하고 두 접속 설정 파일을 작성합니다.")
    parser.add_argument("--scope", choices=["project", "user"])
    parser.add_argument("--project-dir", help="프로젝트 기준 폴더. 기본값은 현재 터미널 폴더입니다.")
    parser.add_argument("--skip-dependencies", action="store_true", help="오프라인 준비 전용. 의존성 검증과 Claude 자동 등록을 생략합니다.")
    parser.add_argument("--no-register", action="store_true", help="파일과 실행환경만 설치하고 Claude 설정은 변경하지 않습니다.")
    args = parser.parse_args(argv)
    try:
        if sys.version_info < (3, 11):
            raise InstallError("Python 3.11 이상이 필요합니다.")
        selection = select_scope(args.scope, args.project_dir)
        result = install(Path(__file__).resolve().parent, selection,
                         skip_dependencies=args.skip_dependencies, register=not args.no_register)
    except (ValueError, OSError, EOFError, KeyboardInterrupt) as exc:
        print(f"설치를 완료하지 못했습니다: {exc}", file=sys.stderr)
        return 2
    print("\n다음 두 파일을 열어 실제 접속정보를 입력하세요.")
    print(f"MongoDB 및 3개 컬렉션: {result['env_file']}")
    print(f"Oracle DB 접속정보: {result['oracle_config']}")
    print(f"Claude 연결 상태: {result['registration']}")
    print(f"수동 연결용 설정: {result['mcp_config']}")
    for warning in result["warnings"]:
        print(warning)
    print("설정 작성 후 Claude Code에서 /mcp를 열어 manufacturing-oracle 연결을 확인하세요.")
    print("DB 접속 검증은 실제 설정 작성 후 MCP의 설정 진단 도구로 진행하세요.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
