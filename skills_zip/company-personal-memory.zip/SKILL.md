---
name: square-company-personal-memory
description: "지속적으로 사용할 개인 선호와 업무 맥락을 저장·검색하고 기존 기억을 조건부로 수정하거나 복원합니다. 일회성 요청과 장기 기억을 구분합니다."
---

# 개인 선호·업무 기억 관리

실제 지침은 [personal-memory](source/skills/personal-memory/SKILL.md)입니다. 해당 본문을 읽고 요청한 작업만 진행하세요.
상대 링크와 스킬 폴더는 `source/skills/personal-memory` 기준입니다. 현재 문맥에서 읽은 동일 본문은 재사용합니다.

기존 Company Agent 런타임과 원본이 요구하는 세션 문맥이 필요합니다. 없으면 제한을 안내하고 임의 CLI 경로·세션을 만들지 마세요.

설치·제거는 [INSTALL.md](INSTALL.md)를 참고하세요. Skill 호출만으로 설치기·의존성 설치·플랫폼 게시를 실행하지 않습니다.
