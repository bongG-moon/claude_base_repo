---
name: square-company-platform-mcp-builder
description: "기존 platform-mcp-builder 명시 호출을 통합 제작 스킬 asset-factory로 연결하는 호환용 이름입니다. 신규 등록용 독립 제작 스킬이 아닙니다."
disable-model-invocation: true
---

# 전사 MCP 제작 이전 이름 호환

실제 지침은 [platform-mcp-builder](source/skills/platform-mcp-builder/SKILL.md)입니다. 해당 본문을 읽고 요청한 작업만 진행하세요.
상대 링크와 스킬 폴더는 `source/skills/platform-mcp-builder` 기준입니다. 현재 문맥에서 읽은 동일 본문은 재사용합니다.

기존 Company Agent 런타임과 원본이 요구하는 세션 문맥이 필요합니다. 없으면 제한을 안내하고 임의 CLI 경로·세션을 만들지 마세요.

설치·제거는 [INSTALL.md](INSTALL.md)를 참고하세요. Skill 호출만으로 설치기·의존성 설치·플랫폼 게시를 실행하지 않습니다.
