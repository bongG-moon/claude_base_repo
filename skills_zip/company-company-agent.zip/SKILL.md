---
name: square-company-company-agent
description: "현재 업무에 맞는 Skill과 작업자를 선택하고 회사 지식·실행 범위·결과 검증을 조율합니다. Company Agent 내부 지원용 Skill입니다."
company-agent-role: support
---

# Company Agent 업무 조율

실제 지침은 [company-agent](source/skills/company-agent/SKILL.md)입니다. 해당 본문을 읽고 요청한 작업만 진행하세요.
상대 링크와 스킬 폴더는 `source/skills/company-agent` 기준입니다. 현재 문맥에서 읽은 동일 본문은 재사용합니다.

기존 Company Agent 런타임과 원본이 요구하는 세션 문맥이 필요합니다. 없으면 제한을 안내하고 임의 CLI 경로·세션을 만들지 마세요.

설치·제거는 [INSTALL.md](INSTALL.md)를 참고하세요. Skill 호출만으로 설치기·의존성 설치·플랫폼 게시를 실행하지 않습니다.
