---
name: huashu-presentation
description: "참고 자료의 색상과 글꼴, 배치를 살려 한 장씩 넘기는 한국어 HTML 발표자료를 만듭니다. 요청하면 Huashu 변환 엔진으로 글자와 도형을 편집할 수 있는 PPTX를 내보냅니다."
---

# Huashu 기반 HTML 발표자료

실제 지침은 [huashu-presentation](source/skills/huashu-presentation/SKILL.md)입니다. 해당 본문을 읽고 요청한 작업만 진행하세요.
상대 링크와 스킬 폴더는 `source/skills/huashu-presentation` 기준입니다. 현재 문맥에서 읽은 동일 본문은 재사용합니다.

이 ZIP에 필요한 작업 지침과 실행 자료가 포함되어 있습니다. 별도 하네스 설치는 필요하지 않으며, Python 등 사용 환경은 INSTALL.md를 확인하세요.

설치·제거는 [INSTALL.md](INSTALL.md)를 참고하세요. Skill 호출만으로 설치기·의존성 설치·플랫폼 게시를 실행하지 않습니다.
