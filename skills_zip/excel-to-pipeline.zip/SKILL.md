---
name: excel-to-pipeline
description: "XLSX와 XLSM의 표와 수식, 접근 가능한 VBA를 분석해 재실행할 수 있는 Python 처리와 업무 흐름 설명서를 만듭니다. Excel 계산과 매크로의 완전 자동 변환은 아닙니다."
---

# 엑셀 업무를 Python 처리로

실제 지침은 [excel-to-pipeline](source/skills/excel-to-pipeline/SKILL.md)입니다. 해당 본문을 읽고 요청한 작업만 진행하세요.
상대 링크와 스킬 폴더는 `source/skills/excel-to-pipeline` 기준입니다. 현재 문맥에서 읽은 동일 본문은 재사용합니다.

이 ZIP에 필요한 작업 지침과 실행 자료가 포함되어 있습니다. 별도 하네스 설치는 필요하지 않으며, Python 등 사용 환경은 INSTALL.md를 확인하세요.

설치·제거는 [INSTALL.md](INSTALL.md)를 참고하세요. Skill 호출만으로 설치기·의존성 설치·플랫폼 게시를 실행하지 않습니다.
