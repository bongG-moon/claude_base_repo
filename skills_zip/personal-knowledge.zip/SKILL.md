---
name: personal-knowledge
description: "업무 용어, 지표, 표 관계를 출처와 적용 범위가 있는 Markdown 지식으로 저장, 조회합니다. 회사 원본은 보존합니다."
---

# 개인 업무 지식 관리

실제 지침은 [personal-knowledge](source/skills/personal-knowledge/SKILL.md)입니다. 해당 본문을 읽고 요청한 작업만 진행하세요.
상대 링크와 스킬 폴더는 `source/skills/personal-knowledge` 기준입니다. 현재 문맥에서 읽은 동일 본문은 재사용합니다.

Company Agent 없이 사용 가능합니다. 필요한 Python 등 의존성은 INSTALL.md를 확인하세요.

설치·제거는 [INSTALL.md](INSTALL.md)를 참고하세요. Skill 호출만으로 설치기·의존성 설치·플랫폼 게시를 실행하지 않습니다.
