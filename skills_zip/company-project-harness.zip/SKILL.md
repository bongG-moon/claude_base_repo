---
name: square-company-project-harness
description: "프로젝트의 목적과 기존 파일을 확인해 작업자 구성·업무 절차·검증 기준을 설계하고 생성합니다. 제작에는 Company Agent가 필요합니다."
---

# 프로젝트 업무 하네스 제작

실제 지침은 [project-harness](source/skills/project-harness/SKILL.md)입니다. 해당 본문을 읽고 요청한 작업만 진행하세요.
상대 링크와 스킬 폴더는 `source/skills/project-harness` 기준입니다. 현재 문맥에서 읽은 동일 본문은 재사용합니다.

기존 Company Agent 런타임과 원본이 요구하는 세션 문맥이 필요합니다. 없으면 제한을 안내하고 임의 CLI 경로·세션을 만들지 마세요.

설치·제거는 [INSTALL.md](INSTALL.md)를 참고하세요. Skill 호출만으로 설치기·의존성 설치·플랫폼 게시를 실행하지 않습니다.
