---
name: web-interface
description: "기존 웹앱의 화면, 페이지, 컴포넌트를 기존 디자인과 실행 환경에 맞춰 개선합니다. 단일 HTML 보고서와 브라우저 업무 자동화는 별도 역할입니다."
---

# 웹 화면 만들고 다듬기

실제 지침은 [web-interface](source/skills/web-interface/SKILL.md)입니다. 해당 본문을 읽고 요청한 작업만 진행하세요.
상대 링크와 스킬 폴더는 `source/skills/web-interface` 기준입니다. 현재 문맥에서 읽은 동일 본문은 재사용합니다.

Company Agent 없이 사용 가능합니다. 필요한 Python 등 의존성은 INSTALL.md를 확인하세요.

설치·제거는 [INSTALL.md](INSTALL.md)를 참고하세요. Skill 호출만으로 설치기·의존성 설치·플랫폼 게시를 실행하지 않습니다.
