---
name: square-company-personal-knowledge
description: "회사 용어·계산식·테이블·업무 기준을 조회하고 개인 적용 지식을 저장·보완합니다. 회사 원본을 유지하며 개인 전체와 현재 프로젝트 범위를 구분합니다."
---

# 개인 업무 지식 관리

실제 지침은 [personal-knowledge](source/skills/personal-knowledge/SKILL.md)입니다. 해당 본문을 읽고 요청한 작업만 진행하세요.
상대 링크와 스킬 폴더는 `source/skills/personal-knowledge` 기준입니다. 현재 문맥에서 읽은 동일 본문은 재사용합니다.

기존 Company Agent 런타임과 원본이 요구하는 세션 문맥이 필요합니다. 없으면 제한을 안내하고 임의 CLI 경로·세션을 만들지 마세요.

설치·제거는 [INSTALL.md](INSTALL.md)를 참고하세요. Skill 호출만으로 설치기·의존성 설치·플랫폼 게시를 실행하지 않습니다.
