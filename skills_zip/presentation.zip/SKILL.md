---
name: presentation
description: "참고 PPT·HTML·이미지의 배치와 문장 스타일을 살펴 HTML 초안을 만들고 글자·도형·표·차트를 편집할 수 있는 PPT로 제작합니다."
---

# 편집 가능한 업무 발표자료

실제 지침은 [presentation](source/skills/presentation/SKILL.md)입니다. 해당 본문을 읽고 요청한 작업만 진행하세요.
상대 링크와 스킬 폴더는 `source/skills/presentation` 기준입니다. 현재 문맥에서 읽은 동일 본문은 재사용합니다.

Company Agent 없이 사용 가능합니다. 필요한 Python 등 의존성은 INSTALL.md를 확인하세요.

설치·제거는 [INSTALL.md](INSTALL.md)를 참고하세요. Skill 호출만으로 설치기·의존성 설치·플랫폼 게시를 실행하지 않습니다.
