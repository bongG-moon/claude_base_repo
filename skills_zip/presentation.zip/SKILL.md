---
name: presentation
description: "첨부 PPT와 이미지의 글꼴, 표, 도형, 말투와 색 조합을 참고해 한글 HTML 발표본을 만듭니다. 모든 디자인에서 페이지 이동과 문구 편집, 수정본 저장을 제공하며 요청하면 확인한 발표본을 편집 가능한 PPT로 내보냅니다."
---

# 편집 가능한 업무 발표자료

실제 지침은 [presentation](source/skills/presentation/SKILL.md)입니다. 해당 본문을 읽고 요청한 작업만 진행하세요.
상대 링크와 스킬 폴더는 `source/skills/presentation` 기준입니다. 현재 문맥에서 읽은 동일 본문은 재사용합니다.

이 ZIP에 필요한 작업 지침과 실행 자료가 포함되어 있습니다. 별도 하네스 설치는 필요하지 않으며, Python 등 사용 환경은 INSTALL.md를 확인하세요.

설치·제거는 [INSTALL.md](INSTALL.md)를 참고하세요. Skill 호출만으로 설치기·의존성 설치·플랫폼 게시를 실행하지 않습니다.
