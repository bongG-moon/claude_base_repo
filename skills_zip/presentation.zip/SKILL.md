---
name: presentation
description: "참고 PPT, HTML과 이미지의 글꼴, 배치, 도형과 색 조합을 새 내용에 반영합니다. 자유 HTML로 제작하고 브라우저에서 문구와 개체를 수정해 저장합니다. 요청하면 저장된 HTML을 PPTX로 내보냅니다."
---

# 편집 가능한 HTML 발표자료

실제 지침은 [presentation](source/skills/presentation/SKILL.md)입니다. 해당 본문을 읽고 요청한 작업만 진행하세요.
상대 링크와 스킬 폴더는 `source/skills/presentation` 기준입니다. 현재 문맥에서 읽은 동일 본문은 재사용합니다.

이 ZIP에 필요한 작업 지침과 실행 자료가 포함되어 있습니다. 별도 하네스 설치는 필요하지 않으며, Python 등 사용 환경은 INSTALL.md를 확인하세요.

설치·제거는 [INSTALL.md](INSTALL.md)를 참고하세요. Skill 호출만으로 설치기·의존성 설치·플랫폼 게시를 실행하지 않습니다.
