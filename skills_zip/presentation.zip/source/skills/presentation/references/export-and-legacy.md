# PPTX 또는 이전 프로젝트

HTML만 요청했다면 이 문서를 읽거나 추가 승인을 받지 않습니다. PPTX도 요청하면 마지막으로 저장한 HTML을 정본으로 삼습니다. 브라우저에서 편집한 자료를 이전 job으로 덮어쓰지 않습니다.

현재 HTML을 확인한 사용자가 PPTX 내보내기를 요청하면 다음 명령을 한 번 실행합니다. 이미 받은 승인과 검사를 다시 요구하지 않습니다.

```text
node "스킬폴더/scripts/export_pptx.cjs" --input "presentation/outputs/발표본.html" --output "presentation/outputs/발표본.pptx"
```

Node.js와 설치된 `playwright` 또는 `playwright-core`, Chrome 또는 Edge가 필요합니다. 없다면 부족한 항목을 알리고 HTML은 그대로 전달합니다. 자동 전역 설치와 브라우저 다운로드는 하지 않습니다. 기존 실행 파일과 의존성이 별도 위치에 있으면 `--browser "실행파일" --node-modules "node_modules폴더"`를 추가합니다.

MIT 라이선스의 dom-to-pptx 2.1.2 번들이 ZIP에 포함됩니다. 저장된 HTML의 스크립트와 이벤트 속성을 실행하지 않고 모든 장의 실제 배치를 로컬 브라우저에서 측정합니다. 변환용 브라우저의 외부 연결은 차단합니다. 텍스트, 지원하는 단순 도형과 표는 편집 가능한 개체로 옮기지만 복잡한 장식은 이미지일 수 있습니다. SVG는 벡터 **그림**이며 개별 도형으로 바꾸려면 Office의 변환 기능이 필요할 수 있습니다. 차트 그림과 데이터 값까지 편집할 수 있는 네이티브 차트는 다릅니다. 원본과 동일한 모양과 모든 개체의 편집성을 보장하지 않습니다.

장 크기는 문서의 `--slide-width`/`--slide-height` 또는 실제 장 영역에서 읽습니다. 크기가 서로 다른 장은 조용히 늘이거나 자르지 않고 알려줍니다. 브라우저에서 한 줄로 확인된 문구는 해당 PPT 텍스트 상자에서도 불필요하게 줄이 바뀌지 않도록 보정합니다. 이미 여러 줄인 문구와 원본의 영역 넘침까지 자동 해결한다고 보장하지 않으며 실행 결과의 `layoutWarnings`를 확인합니다.

전체 장 이미지, 텍스트 개체, 네이티브 표/차트, 개별 벡터 도형을 구분해 결과를 설명합니다. 실제 PPT 화면을 확인할 수 없으면 구조 검사만 통과했다고 적습니다. 변환을 위해 HTML을 고정 카드 양식으로 다시 만들지 않습니다.

이전 정적 변환 경로는 [html-deck.md](html-deck.md)에 남아 있습니다. SVG, 회전과 복잡한 CSS는 지원하지 않을 수 있습니다. 그 제약을 새 HTML 디자인에 강제하지 말고, 정상 변환 수단이 없다면 HTML을 유지한 채 PPTX 미생성 사유를 알립니다.

기존 job 수정 요청은 [schema.md](schema.md)와 `presentation.py draft/build/template` API를 사용할 수 있습니다. 기존 흑백 양식을 명시한 경우에만 [korean-report-deck.md](korean-report-deck.md)를 사용합니다. 새 기본 경로는 `slides.py build`입니다.
