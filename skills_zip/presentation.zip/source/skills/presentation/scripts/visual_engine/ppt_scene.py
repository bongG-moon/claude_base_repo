"""Validated native slide primitives, shared by HTML preview and PPT export.

No code evaluation. Coordinates and typography are in slide points. HTML import
normalizes browser pixels into these same primitives before approval.
"""
from __future__ import annotations

import base64
import math
import re
from copy import deepcopy

from .business_artifacts import ArtifactError, _image, _normalize, _text


def number(value, low, high):
    if type(value) not in (int, float) or not math.isfinite(value) or not low <= value <= high:
        raise ArtifactError('invalid_ppt_element', 'PPT 개체의 좌표·크기·효과 범위를 확인해 주세요.')
    return float(value)


def ink(value, palette, *, transparent=False):
    if transparent and value in (None, 'none'):
        return None
    value = palette.get(value, value) if isinstance(value, str) else value
    if not isinstance(value, str) or not re.fullmatch('[0-9A-Fa-f]{6}', value):
        raise ArtifactError('invalid_ppt_element', '개체 색상은 여섯 자리 RGB 또는 지정된 테마 색상입니다.')
    return value.upper()


def elements(rows, width, height, palette, *, embedded=False):
    if not isinstance(rows, list) or not 1 <= len(rows) <= 1200:
        raise ArtifactError('invalid_ppt_element', '한 장에는 1~1200개 편집 개체를 사용할 수 있습니다.')
    checked = []
    image_bytes = 0
    for raw in rows:
        if not isinstance(raw, dict) or raw.get('kind') not in ('text', 'shape', 'line', 'path', 'image', 'table', 'chart'):
            raise ArtifactError('invalid_ppt_element', '지원하는 개체는 text, shape, line, path, image, table, chart입니다.')
        e = {'kind': raw['kind']}
        if raw.get('group') is not None:
            group = raw['group']
            if not isinstance(group, str) or not re.fullmatch(r'[\w-]{1,64}', group) or raw['kind'] not in ('text','shape','line','path','image'):
                raise ArtifactError('invalid_ppt_group', '그룹 이름은 64자 이하의 글자·숫자·밑줄·하이픈이며 글자·도형·그림만 묶습니다. 표·차트는 독립 개체로 유지하세요.')
            e['group'] = group
        if raw['kind'] in ('shape','line','path'):
            from .ppt_primitives import normalize_primitive
            e.update(normalize_primitive(raw,width,height,palette))
            checked.append(e)
            continue
        for key, maximum in (('x', width), ('y', height), ('w', width), ('h', height)):
            e[key] = number(raw.get(key), 0 if key in ('x', 'y') else .01, maximum)
        if e['x']+e['w'] > width+.5 or e['y']+e['h'] > height+.5:
            raise ArtifactError('ppt_element_out_of_bounds', '화면 밖으로 나간 개체가 있습니다. HTML/개체 배치를 수정해 주세요.')
        kind = e['kind']
        if kind == 'text':
            e.update(text=_text(raw.get('text', ''), 12000), size=number(raw.get('size',18), 6, 200),
                     color=ink(raw.get('color','text'),palette), bold=bool(raw.get('bold',False)),
                     italic=bool(raw.get('italic',False)), underline=bool(raw.get('underline',False)))
            e['align'] = raw.get('align','left')
            if e['align'] not in ('left','center','right'):
                raise ArtifactError('invalid_ppt_element','글자 정렬은 left, center, right입니다.')
            e['wrap'] = raw.get('wrap', True) is not False
            e['lineSpacing'] = number(raw.get('lineSpacing',1.15), .8, 3)
            e['font'] = _text(raw.get('font',''), 80)
            if 'verticalAlign' in raw:
                if raw['verticalAlign'] not in ('top','middle','bottom'):
                    raise ArtifactError('invalid_ppt_element','세로 정렬은 top, middle, bottom입니다.')
                e['verticalAlign'] = raw['verticalAlign']
            if raw.get('allowOverlap') is True:
                e['allowOverlap'] = True
            if 'runs' in raw:
                from .ppt_text import normalize_runs
                e['text'],e['runs'] = normalize_runs(raw,e,palette)
        elif kind == 'image':
            value = raw.get('image')
            if embedded and isinstance(value,dict) and 'data' in value:
                binary = base64.b64decode(value['data'],validate=True)
                mime = 'image/png' if binary.startswith(b'\x89PNG\r\n\x1a\n') else 'image/jpeg' if binary.startswith(b'\xff\xd8\xff') else None
                if not mime or len(binary)>10*1024*1024:
                    raise ArtifactError('invalid_image','PNG/JPEG 그림만 사용할 수 있습니다.')
                e['image'] = {'data':value['data'],'mime':mime,'alt':_text(value.get('alt',''),1000)}
            else:
                e['image'] = _image(value)
            e['fit'] = raw.get('fit','contain')
            if e['fit'] not in ('contain','cover','stretch'):
                raise ArtifactError('invalid_ppt_element','이미지 맞춤은 contain, cover, stretch입니다.')
            image_bytes += len(e['image']['data'])
            if image_bytes>32*1024*1024:
                raise ArtifactError('spec_too_large','한 장의 그림 자료가 너무 큽니다. 그림 용량을 줄여 주세요.')
        else:
            e[kind] = _normalize({'slides':[{kind:raw.get(kind)}]})['sections'][0][kind]
            if kind + 'Style' in raw:
                from .ppt_component_styles import normalize
                e[kind + 'Style'] = normalize(kind, raw[kind + 'Style'])
            if kind == 'table':
                table = e[kind]
                count, columns = len(table['rows'])+1, len(table['headers'])
                e['size'] = number(e.get('tableStyle', {}).get('fontSize',raw.get('size',16)),6,96)
                for key,n,span in (('columnWidths',columns,e['w']),('rowHeights',count,e['h'])):
                    sizes = raw.get(key,[span/n]*n)
                    if not isinstance(sizes,list) or len(sizes)!=n:
                        raise ArtifactError('invalid_ppt_element','표의 행·열 크기가 내용과 다릅니다.')
                    e[key] = [number(v,.01,span) for v in sizes]
                    if abs(sum(e[key])-span)>.5:
                        raise ArtifactError('invalid_ppt_element','표의 행·열 크기 합계가 지정 영역과 다릅니다.')
            elif len(e[kind]['series'])>4 or len(e[kind]['categories'])>12:
                raise ArtifactError('invalid_ppt_element','차트는 12항목·4계열 이하로 나누어 주세요.')
        checked.append(e)
    # Grouping non-adjacent objects changes paint order. Require explicit blocks.
    seen, previous = set(), None
    for e in checked:
        group = e.get('group')
        if group != previous and group in seen:
            raise ArtifactError('invalid_ppt_group', '같은 그룹 개체를 연속 배치해 주세요. 겹침 순서를 임의로 바꾸지 않습니다.')
        if group:
            seen.add(group)
        previous = group
    return checked


def group_shapes(slide, elements):
    """Create real, ungroupable PPT groups without changing paint order or geometry."""
    shapes = list(slide.shapes)
    if len(shapes) != len(elements):
        raise ValueError('Native element/shape count mismatch')
    groups = {}
    for element, shape in zip(elements, shapes):
        if element.get('group'):
            groups.setdefault(element['group'], []).append(shape)
    count = 0
    for name, members in groups.items():
        if len(members) < 2:
            continue
        tree = slide.shapes._spTree
        position = tree.index(members[0]._element)
        group = slide.shapes.add_group_shape(members)
        group.name = name
        tree.remove(group._element)
        tree.insert(position, group._element)
        count += 1
    return count


def add_shape(slide, e, box):
    from pptx.enum.shapes import MSO_SHAPE
    from pptx.dml.color import RGBColor
    from pptx.util import Pt
    from pptx.oxml.xmlchemy import OxmlElement
    kinds = {'rect':MSO_SHAPE.RECTANGLE,'roundRect':MSO_SHAPE.ROUNDED_RECTANGLE,'ellipse':MSO_SHAPE.OVAL}
    shape = slide.shapes.add_shape(kinds[e['shape']],*box)
    if e['shape']=='roundRect':
        shape.adjustments[0] = e['radius']/min(e['w'],e['h'])
    if e['fill']:
        shape.fill.solid()
        shape.fill.fore_color.rgb = RGBColor.from_string(e['fill'])
        alpha = OxmlElement('a:alpha')
        alpha.set('val',str(round(e['opacity']*100000)))
        shape.fill.fore_color._color._xClr.append(alpha)
    else:
        shape.fill.background()
    if e['border'] and e['borderWidth']:
        shape.line.color.rgb = RGBColor.from_string(e['border'])
        shape.line.width = Pt(e['borderWidth'])
    else:
        shape.line.fill.background()
    # Explicit effect list also disables inherited theme shadows.
    effects = shape._element.spPr.get_or_add_effectLst()
    for child in list(effects):
        effects.remove(child)
    if e.get('shadow'):
        s = e['shadow']
        shadow = OxmlElement('a:outerShdw')
        for key,value in {'blurRad':round(s['blur']*12700),'dist':round(math.hypot(s['x'],s['y'])*12700),
                          'dir':round(math.degrees(math.atan2(s['y'],s['x']))%360*60000),
                          'algn':'tl','rotWithShape':'0'}.items():
            shadow.set(key,str(value))
        rgb = OxmlElement('a:srgbClr'); rgb.set('val',s['color'])
        alpha = OxmlElement('a:alpha'); alpha.set('val',str(round(s['opacity']*100000)))
        rgb.append(alpha); shadow.append(rgb); effects.append(shadow)
    return shape


def fit_picture(picture, box, mode):
    """Centered fit from original bitmap dimensions; safe for existing pictures too."""
    x,y,w,h = box
    iw,ih = picture.image.size
    picture.crop_left = picture.crop_right = picture.crop_top = picture.crop_bottom = 0
    if mode == 'contain':
        scale = min(w/iw,h/ih)
        pw,ph = round(iw*scale),round(ih*scale)
        picture.left,picture.top = round(x+(w-pw)/2),round(y+(h-ph)/2)
        picture.width,picture.height = pw,ph
    else:
        picture.left,picture.top,picture.width,picture.height = x,y,w,h
        if mode == 'cover':
            scale = max(w/iw,h/ih)
            picture.crop_left = picture.crop_right = max(0,(iw*scale-w)/(2*iw*scale))
            picture.crop_top = picture.crop_bottom = max(0,(ih*scale-h)/(2*ih*scale))


def template_layouts(plan):
    """Only geometry/styles and synthetic slot values; never retain source text/images."""
    pages = []
    for page in plan['pages']:
        result = []
        slot = 0
        for original in page['elements']:
            if original['kind'] == 'image':
                # Image content and paths are not a reusable style preference.
                result.append(dict(kind='shape',shape='rect',fill='EEF1F4',border='CBD2DA',borderWidth=1,
                                   **{k:original[k] for k in ('x','y','w','h')}))
                continue
            e = deepcopy(original)
            if e['kind']=='text':
                slot += 1
                e['text'] = '예시'
                e.pop('runs',None)  # Never retain business text in a reusable style.
            elif e['kind']=='chart':
                c=e['chart']
                # Rebuild, do not mutate the original payload: auto-layout
                # charts also contain business titles, and future metadata or
                # series fields must not leak into the hidden template JSON.
                e['chart']={'type':c['type'],
                            'categories':[f'항목 {i+1}' for i in range(len(c['categories']))],
                            'series':[{'name':f'계열 {i+1}', 'values':[100+i*10]*len(c['categories'])}
                                      for i in range(len(c['series']))]}
            elif e['kind']=='table':
                t=e['table']
                e['table']={'headers':[f'열 {i+1}' for i in range(len(t['headers']))],
                            'rows':[['예시']*len(t['headers']) for _ in t['rows']]}
            result.append(e)
        pages.append({'elements':result,'textSlots':slot,'background':page.get('background','FFFFFF')})
    return pages
