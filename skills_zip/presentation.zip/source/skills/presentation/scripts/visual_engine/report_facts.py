"""Bounded arithmetic and reusable report numbers; no eval, files or model calls.

Only declared bindings/checks are verified. Free prose and source authenticity
are deliberately not marked verified by this module.
"""
from __future__ import annotations
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
import json
import re
from typing import Any


class FactError(ValueError):
    pass


# Optional meaning supplied by the author, never inferred or fetched. Keeping
# it in the existing fact lets table notes and cross-format handoffs reuse it.
CONTEXT_FIELDS = {"period": 100, "scope": 500, "exclusions": 500,
                  "denominator": 300, "source": 500}
HANDOFF_MAX_ITEMS = 12
HANDOFF_MAX_CHARS = 4000


def number(value: Any) -> Decimal:
    if isinstance(value, bool) or not isinstance(value, (str, int, float, Decimal)):
        raise FactError("계산에는 숫자만 사용해 주세요.")
    if isinstance(value, str) and not re.fullmatch(r"[+-]?(?:\d+(?:\.\d*)?|\.\d+)", value.strip()):
        raise FactError("계산 대상 셀에는 단위나 쉼표 없이 숫자를 넣어 주세요.")
    try:
        result = Decimal(str(value).strip())
    except InvalidOperation:
        raise FactError("계산에 사용할 수 없는 숫자입니다.") from None
    if not result.is_finite() or abs(result) > Decimal("1e15"):
        raise FactError("계산 숫자의 범위를 확인해 주세요.")
    return result


def resolve(spec: dict, sections: list[dict]) -> tuple[dict, dict]:
    raw = spec.get("facts", [])
    if not isinstance(raw, list) or len(raw) > 128:
        raise FactError("공통 수치는 128개 이하로 지정해 주세요.")
    facts: dict[str, dict] = {}

    def operand(value):
        if not isinstance(value, dict):
            return number(value)
        if set(value) == {"fact"}:
            key = value["fact"]
            if not isinstance(key, str) or key not in facts:
                raise FactError("수치 참조는 먼저 정의된 공통 수치만 사용할 수 있습니다.")
            return facts[key]["number"]
        if len(value) != 1 or next(iter(value)) not in {"table", "chart"}:
            raise FactError("표 또는 차트의 셀 위치로 수치를 참조해 주세요.")
        kind, pos = next(iter(value.items()))
        if not isinstance(pos, list) or len(pos) != 3 or any(type(i) is not int or i < 0 for i in pos):
            raise FactError("셀 참조에는 0부터 시작하는 위치 3개가 필요합니다.")
        try:
            section = sections[pos[0]]
            cell = section[kind]["rows"][pos[1]][pos[2]] if kind == "table" else section[kind]["series"][pos[1]]["values"][pos[2]]
        except (IndexError, KeyError, TypeError):
            raise FactError("계산에 참조한 표/차트 셀을 찾을 수 없습니다.") from None
        return number(cell)

    for row in raw:
        if not isinstance(row, dict):
            raise FactError("공통 수치의 형식을 확인해 주세요.")
        key = row.get("id")
        if not isinstance(key, str) or not re.fullmatch(r"[a-zA-Z][a-zA-Z0-9_-]{0,63}", key) or key in facts:
            raise FactError("공통 수치 ID는 중복 없는 영문 이름이어야 합니다.")
        inputs = row.get("inputs", [])
        if not isinstance(inputs, list) or not 1 <= len(inputs) <= 7200:
            raise FactError("계산 입력 개수를 확인해 주세요.")
        values = [operand(v) for v in inputs]
        op = row.get("op", "sum")
        if op == "sum":
            calculated = sum(values, Decimal(0))
        elif op == "value" and len(values) == 1:
            calculated = values[0]
        elif op in ("ratio", "difference", "percent_change") and len(values) == 2:
            left, right = values
            if op == "difference":
                calculated = left - right
            elif right == 0:
                raise FactError("분모가 0인 비율은 계산할 수 없습니다. 확인 필요로 표시해 주세요.")
            else:
                calculated = (left / right if op == "ratio" else (left - right) / right) * 100
        else:
            raise FactError("지원하는 계산식과 입력 개수를 확인해 주세요.")
        calculated = number(calculated)
        digits = row.get("decimals", 0)
        if type(digits) is not int or not 0 <= digits <= 6:
            raise FactError("표시할 소수 자릿수는 0~6 사이여야 합니다.")
        quantum = Decimal(1).scaleb(-digits)
        rounded = calculated.quantize(quantum, rounding=ROUND_HALF_UP)
        if "expected" in row and number(row["expected"]).quantize(quantum, rounding=ROUND_HALF_UP) != rounded:
            raise FactError(f"공통 수치 {key}의 기대값과 실제 계산이 다릅니다. 요약과 원자료를 확인해 주세요.")
        label, unit = row.get("label", key), row.get("unit", "")
        if not isinstance(label, str) or len(label) > 200 or not isinstance(unit, str) or len(unit) > 30:
            raise FactError("지표 이름과 단위를 짧은 글자로 지정해 주세요.")
        facts[key] = {"number": calculated, "display": f"{rounded:,.{digits}f}", "label": label, "unit": unit}
        for field, limit in CONTEXT_FIELDS.items():
            if field not in row:
                continue
            value = row[field]
            if (not isinstance(value, str) or not value.strip() or len(value) > limit
                    or any(ord(c) < 32 or ord(c) == 127 for c in value)):
                raise FactError(f"지표의 {field}는 비어 있지 않은 {limit}자 이하 글자로 지정해 주세요.")
            facts[key][field] = value
    checks = spec.get("checks", [])
    if not isinstance(checks, list) or len(checks) > 128:
        raise FactError("수치 대조 항목은 128개 이하로 지정해 주세요.")
    for check in checks:
        if not isinstance(check, dict) or not isinstance(check.get("left"), str) or not isinstance(check.get("right"), str) or check["left"] not in facts or check["right"] not in facts:
            raise FactError("대조할 공통 수치를 찾을 수 없습니다.")
        if facts[check["left"]]["number"] != facts[check["right"]]["number"]:
            raise FactError("표·차트·총계의 수치가 일치하지 않습니다. 결과물을 만들기 전에 수정해 주세요.")
    validation = {"arithmetic": "checked" if facts else "not_provided", "facts": len(facts), "crossChecks": len(checks),
                  "sourceAccuracy": "not_verified", "freeTextClaims": "not_verified", "visual": "not_verified",
                  "metricMeaning": "not_verified"}
    if facts:
        handoff = compact_handoff(facts, max_items=HANDOFF_MAX_ITEMS, max_chars=HANDOFF_MAX_CHARS)
        validation["factHandoff"] = handoff
        validation["factHandoffOmitted"] = len(facts) - len(handoff)
    return facts, validation


def statement(fact: dict) -> str:
    """Join the author's metric name with its computed value, without inference."""
    return f"{fact['label']} {fact['display']}{fact['unit']}"


def compact_handoff(facts: dict, *, max_items: int | None = None,
                    max_chars: int | None = None) -> list[dict]:
    """Reuse resolved metric wording and declared context in an existing handoff.

    No model calls, source reads, new checks or separate handoff file are needed.
    The resolved Decimal is intentionally omitted to keep the result JSON-safe.
    Optional context stays separate so slide titles need not contain long notes.
    Automatic responses pass small limits. Keep complete rows in source order;
    the character budget measures compact JSON with Unicode preserved.
    """
    result = []
    used = 2  # JSON list brackets
    for key, fact in facts.items():
        row = dict(id=key, statement=statement(fact),
                   **{field: fact[field] for field in CONTEXT_FIELDS if field in fact})
        size = len(json.dumps(row, ensure_ascii=False, separators=(',', ':'))) + bool(result)
        if ((max_items is not None and len(result) >= max_items)
                or (max_chars is not None and used + size > max_chars)):
            break
        result.append(row)
        used += size
    return result


def bind(text: str, facts: dict) -> str:
    """Reuse declared metadata, not infer or validate the meaning of free prose.

    Legacy ``{{fact:id}}`` remains numeric only. Metadata substitution is one
    pass: a label containing another binding is never evaluated recursively.
    Renderers remain responsible for HTML/XML escaping of the plain text.
    """
    def replace(match):
        key, field = match.group(1), match.group(2)
        if key not in facts:
            raise FactError("본문이 참조한 공통 수치를 찾을 수 없습니다.")
        fact = facts[key]
        if field is None:
            return fact["display"]
        if field == "valueWithUnit":
            return fact["display"] + fact["unit"]
        if field == "statement":
            return statement(fact)
        if field in ("label", "unit") or field in CONTEXT_FIELDS:
            if field not in fact:
                raise FactError(f"참조한 공통 수치에 {field}를 먼저 지정해 주세요.")
            return fact[field]
        raise FactError("수치 참조 필드는 label, unit, valueWithUnit, statement, period, scope, exclusions, denominator, source만 지원합니다.")
    result = re.sub(r"\{\{fact:([a-zA-Z][a-zA-Z0-9_-]{0,63})(?:\.([a-zA-Z]+))?\}\}", replace, text)
    if "{{fact:" in result:
        raise FactError("본문 수치 참조 형식을 확인해 주세요.")
    return result
