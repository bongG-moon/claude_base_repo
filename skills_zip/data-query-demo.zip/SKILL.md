---
name: data-query-demo
description: "계정 없이 가상 데이터로 쿼리 저장, 조건 변경과 큰 조회 확인을 연습합니다. Oracle, Datalake와 E-HUB의 같은 처리 흐름을 연결 없이 시험합니다."
---

# 데이터 조회 연습

실제 지침은 [data-query-demo](source/skills/data-query-demo/SKILL.md)입니다. 해당 본문을 읽고 요청한 작업만 진행하세요.
상대 링크와 스킬 폴더는 `source/skills/data-query-demo` 기준입니다. 현재 문맥에서 읽은 동일 본문은 재사용합니다.

이 ZIP에 필요한 작업 지침과 실행 자료가 포함되어 있습니다. 별도 하네스 설치는 필요하지 않으며, Python 등 사용 환경은 INSTALL.md를 확인하세요.

설치·제거는 [INSTALL.md](INSTALL.md)를 참고하세요. Skill 호출만으로 설치기·의존성 설치·플랫폼 게시를 실행하지 않습니다.
