---
name: web-api-discovery
description: "사용이 허용된 웹사이트에서 필요한 데이터 조회 방법을 찾고 재사용할 Python 코드를 만듭니다. 연결된 브라우저의 네트워크 관찰 기능이나 공식 API 문서를 활용합니다."
---

# 웹 데이터 조회 절차 만들기

실제 지침은 [web-api-discovery](source/skills/web-api-discovery/SKILL.md)입니다. 해당 본문을 읽고 요청한 작업만 진행하세요.
상대 링크와 스킬 폴더는 `source/skills/web-api-discovery` 기준입니다. 현재 문맥에서 읽은 동일 본문은 재사용합니다.

이 ZIP에 필요한 작업 지침과 실행 자료가 포함되어 있습니다. 별도 하네스 설치는 필요하지 않으며, Python 등 사용 환경은 INSTALL.md를 확인하세요.

설치·제거는 [INSTALL.md](INSTALL.md)를 참고하세요. Skill 호출만으로 설치기·의존성 설치·플랫폼 게시를 실행하지 않습니다.
