---
name: oracle-query
description: "Oracle 쿼리를 저장하며 작은 실제 조회로 확인하고, 새 요청은 다시 조회합니다. 결과는 파일로 저장하며 Python으로 A 결과를 B의 조건에 전달할 수 있습니다."
---

# Oracle 데이터 조회

실제 지침은 [oracle-query](source/skills/oracle-query/SKILL.md)입니다. 해당 본문을 읽고 요청한 작업만 진행하세요.
상대 링크와 스킬 폴더는 `source/skills/oracle-query` 기준입니다. 현재 문맥에서 읽은 동일 본문은 재사용합니다.

이 ZIP에 필요한 작업 지침과 실행 자료가 포함되어 있습니다. 별도 하네스 설치는 필요하지 않으며, Python 등 사용 환경은 INSTALL.md를 확인하세요.

설치·제거는 [INSTALL.md](INSTALL.md)를 참고하세요. Skill 호출만으로 설치기·의존성 설치·플랫폼 게시를 실행하지 않습니다.
