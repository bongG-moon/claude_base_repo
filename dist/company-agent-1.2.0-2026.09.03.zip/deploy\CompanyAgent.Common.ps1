Set-StrictMode -Version 2.0

function ConvertTo-CompanyAgentProcessArgument {
    param([Parameter(Mandatory = $true)] [AllowEmptyString()] [string] $Value)

    # ProcessStartInfo.ArgumentList is unavailable in Windows PowerShell 5.1.
    # Quote argv entries using the Windows CRT rules, never a shell command.
    # Leave simple options unquoted: older py.exe launchers inspect the raw
    # command line and do not recognize a quoted "-3" interpreter selector.
    if ($Value.IndexOf([char]0) -ge 0) { throw 'Process arguments cannot contain NUL.' }
    if ($Value.Length -gt 0 -and $Value -notmatch '[\s"]') { return $Value }
    $quoted = New-Object Text.StringBuilder
    $null = $quoted.Append('"')
    $backslashes = 0
    foreach ($character in $Value.ToCharArray()) {
        if ($character -eq [char]'\') { $backslashes++; continue }
        if ($character -eq [char]'"') {
            $null = $quoted.Append(('\' * (2 * $backslashes + 1)))
            $null = $quoted.Append('"')
        }
        else {
            $null = $quoted.Append(('\' * $backslashes))
            $null = $quoted.Append($character)
        }
        $backslashes = 0
    }
    $null = $quoted.Append(('\' * (2 * $backslashes)))
    $null = $quoted.Append('"')
    return $quoted.ToString()
}

function Invoke-CompanyAgentPythonProcess {
    param(
        [Parameter(Mandatory = $true)] [string] $Executable,
        [AllowEmptyCollection()] [string[]] $Arguments = @(),
        [string] $WorkingDirectory,
        [ValidateRange(1, 600000)] [int] $TimeoutMilliseconds = 30000
    )

    # Do not invoke aliases, CMD/PowerShell wrappers, or the Store. Installation
    # resolves an existing interpreter (or probes an existing py.exe) first.
    if (-not [IO.Path]::IsPathRooted($Executable) -or
        [IO.Path]::GetExtension($Executable) -ine '.exe' -or
        -not (Test-Path -LiteralPath $Executable -PathType Leaf)) {
        throw "Python executable must be an existing absolute .exe path: $Executable"
    }
    $executableItem = Get-Item -LiteralPath $Executable -Force
    if (($executableItem.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0 -and $executableItem.Length -eq 0) {
        throw 'A Windows Store execution alias is not an installed Python interpreter. Select the existing company-approved python.exe.'
    }
    $process = New-Object Diagnostics.Process
    $timer = [Diagnostics.Stopwatch]::StartNew()
    $started = $false
    try {
        $process.StartInfo.FileName = $Executable
        $process.StartInfo.Arguments = (@($Arguments | ForEach-Object { ConvertTo-CompanyAgentProcessArgument -Value $_ }) -join ' ')
        $process.StartInfo.UseShellExecute = $false
        $process.StartInfo.CreateNoWindow = $true
        $process.StartInfo.RedirectStandardOutput = $true
        $process.StartInfo.RedirectStandardError = $true
        $process.StartInfo.StandardOutputEncoding = New-Object Text.UTF8Encoding($false, $true)
        $process.StartInfo.StandardErrorEncoding = New-Object Text.UTF8Encoding($false, $true)
        if (-not [string]::IsNullOrWhiteSpace($WorkingDirectory)) {
            $process.StartInfo.WorkingDirectory = $WorkingDirectory
        }
        # Set only the child environment. Parent consoles can remain CP949,
        # CP932, or any other code page without corrupting our JSON boundary.
        # Callers using Python -I must additionally pass -X utf8.
        $process.StartInfo.EnvironmentVariables['PYTHONIOENCODING'] = 'utf-8'
        $process.StartInfo.EnvironmentVariables.Remove('PYLAUNCHER_ALLOW_INSTALL')
        $process.StartInfo.EnvironmentVariables.Remove('PYLAUNCHER_ALWAYS_INSTALL')
        $process.StartInfo.EnvironmentVariables['PYTHON_MANAGER_AUTOMATIC_INSTALL'] = 'false'
        $started = $process.Start()
        if (-not $started) { throw 'The Python process did not start.' }
        # Drain both streams concurrently; waiting for one stream first can
        # deadlock when the other pipe fills (including during error reporting).
        $stdoutTask = $process.StandardOutput.ReadToEndAsync()
        $stderrTask = $process.StandardError.ReadToEndAsync()
        if (-not $process.WaitForExit($TimeoutMilliseconds)) {
            throw "Python process timed out after $TimeoutMilliseconds ms."
        }
        foreach ($streamTask in @($stdoutTask, $stderrTask)) {
            $remaining = [Math]::Max(0, $TimeoutMilliseconds - [int]$timer.ElapsedMilliseconds)
            if (-not $streamTask.Wait($remaining)) {
                throw "Python output capture timed out after $TimeoutMilliseconds ms."
            }
        }
        return [pscustomobject]@{
            ExitCode = $process.ExitCode
            StdOut = $stdoutTask.GetAwaiter().GetResult()
            StdErr = $stderrTask.GetAwaiter().GetResult()
        }
    }
    finally {
        # Cleanup is bounded too. Do not wait indefinitely for inherited pipe
        # handles held by a child of a timed-out process.
        if ($started -and -not $process.HasExited) {
            try { $process.Kill(); $null = $process.WaitForExit(1000) } catch { }
        }
        $process.Dispose()
        $timer.Stop()
    }
}

function Get-CompanyAgentDefaultInstallRoot {
    $basePath = $env:ProgramFiles
    if ([string]::IsNullOrWhiteSpace($basePath)) {
        $basePath = 'C:\Program Files'
    }

    return (Join-Path $basePath 'CompanyAgent')
}

function Get-CompanyAgentDefaultDataRoot {
    $basePath = $env:ProgramData
    if ([string]::IsNullOrWhiteSpace($basePath)) {
        $basePath = 'C:\ProgramData'
    }

    return (Join-Path $basePath 'CompanyAgent')
}

function Get-CompanyAgentDefaultUserStateRoot {
    $basePath = $env:LOCALAPPDATA
    if ([string]::IsNullOrWhiteSpace($basePath)) {
        $basePath = Join-Path $env:USERPROFILE 'AppData\Local'
    }

    return (Join-Path $basePath 'CompanyAgent')
}

function ConvertTo-CompanyAgentFullPath {
    param(
        [Parameter(Mandatory = $true)]
        [string] $Path
    )

    if ([string]::IsNullOrWhiteSpace($Path)) {
        throw 'Path cannot be empty.'
    }

    if ([System.IO.Path]::IsPathRooted($Path)) {
        return [System.IO.Path]::GetFullPath($Path)
    }

    return [System.IO.Path]::GetFullPath((Join-Path (Get-Location).Path $Path))
}

function Assert-CompanyAgentPathHasNoReparsePoint {
    param(
        [Parameter(Mandatory = $true)]
        [string] $Path,
        [Parameter(Mandatory = $true)]
        [string] $Name
    )

    $current = ConvertTo-CompanyAgentFullPath -Path $Path
    while (-not [string]::IsNullOrWhiteSpace($current)) {
        if (Test-Path -LiteralPath $current) {
            $item = Get-Item -LiteralPath $current -Force
            if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
                throw "$Name cannot use a junction, symbolic link, or other reparse point: $($item.FullName)"
            }
        }
        $parent = Split-Path -Parent $current
        if ([string]::IsNullOrWhiteSpace($parent) -or $parent -ieq $current) {
            break
        }
        $current = $parent
    }
}

function Assert-CompanyAgentRootsSeparated {
    param(
        [Parameter(Mandatory = $true)]
        [string] $InstallRoot,

        [Parameter(Mandatory = $true)]
        [string] $DataRoot,

        [Parameter(Mandatory = $true)]
        [string] $UserStateRoot
    )

    $roots = @(
        [pscustomobject]@{ Name = 'InstallRoot'; Path = (ConvertTo-CompanyAgentFullPath -Path $InstallRoot).TrimEnd([char[]]@('\', '/')) },
        [pscustomobject]@{ Name = 'DataRoot'; Path = (ConvertTo-CompanyAgentFullPath -Path $DataRoot).TrimEnd([char[]]@('\', '/')) },
        [pscustomobject]@{ Name = 'UserStateRoot'; Path = (ConvertTo-CompanyAgentFullPath -Path $UserStateRoot).TrimEnd([char[]]@('\', '/')) }
    )

    foreach ($root in $roots) {
        Assert-CompanyAgentPathHasNoReparsePoint -Path $root.Path -Name $root.Name
    }

    for ($leftIndex = 0; $leftIndex -lt $roots.Count; $leftIndex++) {
        for ($rightIndex = $leftIndex + 1; $rightIndex -lt $roots.Count; $rightIndex++) {
            $left = $roots[$leftIndex]
            $right = $roots[$rightIndex]
            $leftPrefix = $left.Path + [System.IO.Path]::DirectorySeparatorChar
            $rightPrefix = $right.Path + [System.IO.Path]::DirectorySeparatorChar
            if ($left.Path -ieq $right.Path -or
                $left.Path.StartsWith($rightPrefix, [System.StringComparison]::OrdinalIgnoreCase) -or
                $right.Path.StartsWith($leftPrefix, [System.StringComparison]::OrdinalIgnoreCase)) {
                throw ("InstallRoot, DataRoot, and UserStateRoot must be separate non-nested directories. {0}='{1}', {2}='{3}'" -f $left.Name, $left.Path, $right.Name, $right.Path)
            }
        }
    }
}

function Test-CompanyAgentAdministrator {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Assert-CompanyAgentAdministrator {
    param(
        [switch] $SkipAdminCheck
    )

    if ($SkipAdminCheck) {
        return
    }

    if (-not (Test-CompanyAgentAdministrator)) {
        throw 'This operation requires an elevated PowerShell session. For isolated tests only, use -SkipAdminCheck with non-system path overrides.'
    }
}

function Assert-CompanyAgentPrerequisites {
    param(
        [string] $ClaudeCommand = 'claude',
        [string] $PythonCommand = 'python',
        [switch] $SkipPrerequisiteCheck
    )

    if ($SkipPrerequisiteCheck) {
        return
    }

    $claude = Get-Command $ClaudeCommand -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($null -eq $claude) {
        throw "Claude Code CLI was not found on PATH ('$ClaudeCommand'). Install the approved offline Claude Code package first."
    }

    $claudeExecutable = $claude.Source
    if ([string]::IsNullOrWhiteSpace($claudeExecutable)) {
        $claudeExecutable = $claude.Definition
    }
    $claudeVersionText = & $claudeExecutable --version 2>&1
    if ($LASTEXITCODE -ne 0) {
        throw "Could not execute Claude Code prerequisite check: $claudeVersionText"
    }
    $claudeVersionMatch = [regex]::Match([string]($claudeVersionText | Select-Object -Last 1), '(?<![0-9])([0-9]+\.[0-9]+\.[0-9]+)')
    if (-not $claudeVersionMatch.Success) {
        throw "Could not parse Claude Code version: $claudeVersionText"
    }
    $claudeVersion = [version]$claudeVersionMatch.Groups[1].Value
    if ($claudeVersion -lt [version]'2.1.220') {
        throw "Claude Code 2.1.220 or newer is required. Found: $claudeVersion"
    }

    $python = Get-Command $PythonCommand -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($null -eq $python) {
        throw "Python was not found on PATH ('$PythonCommand'). Company Agent requires Python 3.11 or newer."
    }

    $pythonExecutable = $python.Source
    if ([string]::IsNullOrWhiteSpace($pythonExecutable)) {
        $pythonExecutable = $python.Definition
    }
    $pythonResult = Invoke-CompanyAgentPythonProcess -Executable $pythonExecutable -Arguments @('-I', '-X', 'utf8', '-B', '-c', "import sys; print('.'.join(str(v) for v in sys.version_info[:3]))") -TimeoutMilliseconds 10000
    $versionText = $pythonResult.StdOut.Trim()
    if ($pythonResult.ExitCode -ne 0) {
        throw "Could not execute Python prerequisite check: $($pythonResult.StdErr) $versionText"
    }
    try {
        $pythonVersion = [version]$versionText
    }
    catch {
        throw "Could not parse Python version: $versionText"
    }
    if ($pythonVersion -lt [version]'3.11') {
        throw "Python 3.11 or newer is required. Found: $pythonVersion"
    }
}

function Get-CompanyAgentSubagentModelForceSettings {
    param(
        [string[]] $SettingsPaths = @(),
        [switch] $IncludeWindowsPolicy
    )

    $candidateFiles = New-Object Collections.ArrayList
    foreach ($path in @($SettingsPaths)) {
        if (-not [string]::IsNullOrWhiteSpace([string]$path)) {
            $null = $candidateFiles.Add((ConvertTo-CompanyAgentFullPath -Path ([string]$path)))
        }
    }
    if ($IncludeWindowsPolicy) {
        $programFilesRoot = $env:ProgramFiles
        if ([string]::IsNullOrWhiteSpace($programFilesRoot)) {
            $programFilesRoot = 'C:\Program Files'
        }
        $managedRoot = Join-Path $programFilesRoot 'ClaudeCode'
        $null = $candidateFiles.Add((Join-Path $managedRoot 'managed-settings.json'))
        $dropInRoot = Join-Path $managedRoot 'managed-settings.d'
        if (Test-Path -LiteralPath $dropInRoot -PathType Container) {
            foreach ($dropIn in @(Get-ChildItem -LiteralPath $dropInRoot -Filter '*.json' -File -Force | Sort-Object Name)) {
                if (-not $dropIn.Name.StartsWith('.')) {
                    $null = $candidateFiles.Add($dropIn.FullName)
                }
            }
        }
    }

    $forceNames = @('CLAUDE_CODE_SUBAGENT_MODEL', 'CLAUDE_CODE_SUBAGENT_MODEL_FORCE')
    $results = New-Object Collections.ArrayList
    foreach ($settingsPath in @($candidateFiles.ToArray() | Sort-Object -Unique)) {
        if (-not (Test-Path -LiteralPath $settingsPath -PathType Leaf)) {
            continue
        }
        try {
            $settings = Read-CompanyAgentJson -Path $settingsPath
        }
        catch {
            continue
        }
        $envProperty = $settings.PSObject.Properties['env']
        if ($null -eq $envProperty -or $null -eq $envProperty.Value) {
            continue
        }
        foreach ($forceName in $forceNames) {
            $forceProperty = $envProperty.Value.PSObject.Properties[$forceName]
            if ($null -ne $forceProperty -and -not [string]::IsNullOrWhiteSpace([string]$forceProperty.Value)) {
                $null = $results.Add([pscustomobject][ordered]@{
                    variable = $forceName
                    source = $settingsPath
                })
            }
        }
    }

    if ($IncludeWindowsPolicy) {
        foreach ($registryPath in @('HKLM:\SOFTWARE\Policies\ClaudeCode', 'HKCU:\SOFTWARE\Policies\ClaudeCode')) {
            try {
                $registrySettings = [string](Get-ItemProperty -LiteralPath $registryPath -Name 'Settings' -ErrorAction Stop).Settings
                if ([string]::IsNullOrWhiteSpace($registrySettings)) {
                    continue
                }
                $settings = $registrySettings | ConvertFrom-Json
                $envProperty = $settings.PSObject.Properties['env']
                if ($null -eq $envProperty -or $null -eq $envProperty.Value) {
                    continue
                }
                foreach ($forceName in $forceNames) {
                    $forceProperty = $envProperty.Value.PSObject.Properties[$forceName]
                    if ($null -ne $forceProperty -and -not [string]::IsNullOrWhiteSpace([string]$forceProperty.Value)) {
                        $null = $results.Add([pscustomobject][ordered]@{
                            variable = $forceName
                            source = $registryPath
                        })
                    }
                }
            }
            catch {
                continue
            }
        }
    }

    return @($results.ToArray() | Sort-Object source, variable -Unique)
}

function Assert-CompanyAgentVersion {
    param(
        [Parameter(Mandatory = $true)]
        [string] $Version,

        [Parameter(Mandatory = $true)]
        [string] $Name
    )

    if ($Version -notmatch '^[0-9A-Za-z][0-9A-Za-z._-]{0,63}$') {
        throw "$Name '$Version' is invalid. Use 1-64 letters, digits, dots, underscores, or hyphens."
    }
}

function New-CompanyAgentDirectory {
    param(
        [Parameter(Mandatory = $true)]
        [string] $Path
    )

    if (-not (Test-Path -LiteralPath $Path -PathType Container)) {
        New-Item -ItemType Directory -Path $Path -Force | Out-Null
    }
}

function Write-CompanyAgentUtf8File {
    param(
        [Parameter(Mandatory = $true)]
        [string] $Path,

        [Parameter(Mandatory = $true)]
        [AllowEmptyString()]
        [string] $Content
    )

    $parentPath = Split-Path -Parent $Path
    New-CompanyAgentDirectory -Path $parentPath
    $encoding = New-Object System.Text.UTF8Encoding($false)
    [System.IO.File]::WriteAllText($Path, $Content, $encoding)
}

function Write-CompanyAgentJsonAtomic {
    param(
        [Parameter(Mandatory = $true)]
        [string] $Path,

        [Parameter(Mandatory = $true)]
        [object] $Value
    )

    $parentPath = Split-Path -Parent $Path
    New-CompanyAgentDirectory -Path $parentPath
    $temporaryPath = Join-Path $parentPath ((Split-Path -Leaf $Path) + '.tmp.' + [guid]::NewGuid().ToString('N'))
    $json = $Value | ConvertTo-Json -Depth 20

    try {
        Write-CompanyAgentUtf8File -Path $temporaryPath -Content ($json + [Environment]::NewLine)
        Move-Item -LiteralPath $temporaryPath -Destination $Path -Force
    }
    finally {
        if (Test-Path -LiteralPath $temporaryPath) {
            Remove-Item -LiteralPath $temporaryPath -Force -ErrorAction SilentlyContinue
        }
    }
}

function Read-CompanyAgentJson {
    param(
        [Parameter(Mandatory = $true)]
        [string] $Path
    )

    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        throw "Required JSON file was not found: $Path"
    }

    try {
        return (Get-Content -LiteralPath $Path -Raw -Encoding UTF8 | ConvertFrom-Json)
    }
    catch {
        throw "Invalid JSON file '$Path': $($_.Exception.Message)"
    }
}

function Copy-CompanyAgentDirectoryContents {
    param(
        [Parameter(Mandatory = $true)]
        [string] $Source,

        [Parameter(Mandatory = $true)]
        [string] $Destination
    )

    if (-not (Test-Path -LiteralPath $Source -PathType Container)) {
        throw "Source directory was not found: $Source"
    }

    New-CompanyAgentDirectory -Path $Destination
    foreach ($item in @(Get-ChildItem -LiteralPath $Source -Force)) {
        Copy-Item -LiteralPath $item.FullName -Destination $Destination -Recurse -Force
    }
}

function Get-CompanyAgentTreeRecords {
    param(
        [Parameter(Mandatory = $true)]
        [string] $Root
    )

    $fullRoot = (ConvertTo-CompanyAgentFullPath -Path $Root).TrimEnd([char[]]@('\', '/'))
    if (-not (Test-Path -LiteralPath $fullRoot -PathType Container)) {
        throw "Directory was not found: $fullRoot"
    }

    $records = @()
    foreach ($file in @(Get-ChildItem -LiteralPath $fullRoot -Recurse -Force | Where-Object { -not $_.PSIsContainer })) {
        $relativePath = $file.FullName.Substring($fullRoot.Length).TrimStart([char[]]@('\', '/')).Replace('\', '/')
        $records += [pscustomobject][ordered]@{
            path   = $relativePath
            length = [int64]$file.Length
            sha256 = (Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
        }
    }

    return @($records | Sort-Object path)
}

function Test-CompanyAgentDirectoryEquivalent {
    param(
        [Parameter(Mandatory = $true)]
        [string] $Left,

        [Parameter(Mandatory = $true)]
        [string] $Right
    )

    $leftRecords = @(Get-CompanyAgentTreeRecords -Root $Left)
    $rightRecords = @(Get-CompanyAgentTreeRecords -Root $Right)
    if ($leftRecords.Count -ne $rightRecords.Count) {
        return $false
    }

    for ($index = 0; $index -lt $leftRecords.Count; $index++) {
        if ($leftRecords[$index].path -cne $rightRecords[$index].path -or
            $leftRecords[$index].length -ne $rightRecords[$index].length -or
            $leftRecords[$index].sha256 -ne $rightRecords[$index].sha256) {
            return $false
        }
    }

    return $true
}

function Install-CompanyAgentImmutableDirectory {
    param(
        [Parameter(Mandatory = $true)]
        [string] $Source,

        [Parameter(Mandatory = $true)]
        [string] $Destination
    )

    if (Test-Path -LiteralPath $Destination -PathType Container) {
        if (Test-CompanyAgentDirectoryEquivalent -Left $Source -Right $Destination) {
            return $Destination
        }

        throw "Immutable version directory already exists with different content: $Destination. Publish a new version instead of overwriting it."
    }

    $parentPath = Split-Path -Parent $Destination
    New-CompanyAgentDirectory -Path $parentPath
    $stagePath = Join-Path $parentPath ('.staging-' + [guid]::NewGuid().ToString('N'))

    try {
        Copy-CompanyAgentDirectoryContents -Source $Source -Destination $stagePath
        if (-not (Test-CompanyAgentDirectoryEquivalent -Left $Source -Right $stagePath)) {
            throw "Staged file verification failed for $Destination"
        }

        Move-Item -LiteralPath $stagePath -Destination $Destination
        return $Destination
    }
    finally {
        if (Test-Path -LiteralPath $stagePath) {
            Remove-Item -LiteralPath $stagePath -Recurse -Force -ErrorAction SilentlyContinue
        }
    }
}

function Set-CompanyAgentManagedRootMarker {
    param(
        [Parameter(Mandatory = $true)]
        [string] $Root
    )

    New-CompanyAgentDirectory -Path $Root
    $markerPath = Join-Path $Root '.company-agent-managed-root'
    if (-not (Test-Path -LiteralPath $markerPath -PathType Leaf)) {
        Write-CompanyAgentUtf8File -Path $markerPath -Content "CompanyAgentManagedRoot:v1`r`n"
    }
}

function Initialize-CompanyAgentManagedRoot {
    param(
        [Parameter(Mandatory = $true)]
        [string] $Root
    )

    $fullRoot = ConvertTo-CompanyAgentFullPath -Path $Root
    if (Test-Path -LiteralPath $fullRoot -PathType Container) {
        $markerPath = Join-Path $fullRoot '.company-agent-managed-root'
        if (-not (Test-Path -LiteralPath $markerPath -PathType Leaf)) {
            $existingItems = @(Get-ChildItem -LiteralPath $fullRoot -Force)
            if ($existingItems.Count -gt 0) {
                throw "Target directory already contains unmanaged files: $fullRoot"
            }
        }
    }

    Set-CompanyAgentManagedRootMarker -Root $fullRoot
    return $fullRoot
}

function Assert-CompanyAgentManagedRoot {
    param(
        [Parameter(Mandatory = $true)]
        [string] $Root
    )

    $fullRoot = ConvertTo-CompanyAgentFullPath -Path $Root
    $rootOfDrive = [System.IO.Path]::GetPathRoot($fullRoot).TrimEnd([char[]]@('\', '/'))
    if ($fullRoot.TrimEnd([char[]]@('\', '/')) -ieq $rootOfDrive) {
        throw "Refusing to operate on a drive root: $fullRoot"
    }

    $forbidden = @(
        $env:USERPROFILE,
        $env:ProgramFiles,
        $env:ProgramData,
        $env:LOCALAPPDATA,
        $env:TEMP
    )
    foreach ($path in $forbidden) {
        if (-not [string]::IsNullOrWhiteSpace($path)) {
            $fullForbidden = (ConvertTo-CompanyAgentFullPath -Path $path).TrimEnd([char[]]@('\', '/'))
            if ($fullRoot.TrimEnd([char[]]@('\', '/')) -ieq $fullForbidden) {
                throw "Refusing to operate on broad system path: $fullRoot"
            }
        }
    }

    $markerPath = Join-Path $fullRoot '.company-agent-managed-root'
    if (-not (Test-Path -LiteralPath $markerPath -PathType Leaf)) {
        throw "Managed-root marker is missing; refusing destructive operation: $fullRoot"
    }

    $marker = (Get-Content -LiteralPath $markerPath -Raw -Encoding UTF8).Trim()
    if ($marker -ne 'CompanyAgentManagedRoot:v1') {
        throw "Managed-root marker is invalid; refusing destructive operation: $fullRoot"
    }
}

function Set-CompanyAgentCorporateAcl {
    param(
        [Parameter(Mandatory = $true)]
        [string] $Path,

        [switch] $SkipAcl
    )

    if ($SkipAcl) {
        return
    }

    $icacls = Get-Command 'icacls.exe' -ErrorAction SilentlyContinue
    if ($null -eq $icacls) {
        throw 'icacls.exe was not found.'
    }

    $arguments = @(
        $Path,
        '/inheritance:r',
        '/grant:r',
        '*S-1-5-18:(OI)(CI)F',
        '*S-1-5-32-544:(OI)(CI)F',
        '*S-1-5-32-545:(OI)(CI)RX'
    )
    & $icacls.Source @arguments | Out-Null
    if ($LASTEXITCODE -ne 0) {
        throw "Failed to apply corporate read-only ACL to $Path (icacls exit $LASTEXITCODE)."
    }
}

function Set-CompanyAgentPersonalAcl {
    param(
        [Parameter(Mandatory = $true)]
        [string] $Path,

        [switch] $SkipAcl
    )

    if ($SkipAcl) {
        return
    }

    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $userSid = $identity.User.Value
    $icacls = Get-Command 'icacls.exe' -ErrorAction SilentlyContinue
    if ($null -eq $icacls) {
        throw 'icacls.exe was not found.'
    }

    $arguments = @(
        $Path,
        '/inheritance:r',
        '/grant:r',
        '*S-1-5-18:(OI)(CI)F',
        '*S-1-5-32-544:(OI)(CI)F',
        ('*' + $userSid + ':(OI)(CI)F')
    )
    & $icacls.Source @arguments | Out-Null
    if ($LASTEXITCODE -ne 0) {
        throw "Failed to apply personal-state ACL to $Path (icacls exit $LASTEXITCODE)."
    }
}

function Get-CompanyAgentCurrentPointerPath {
    param(
        [Parameter(Mandatory = $true)]
        [string] $DataRoot
    )

    return (Join-Path $DataRoot 'state\current.json')
}

function Get-CompanyAgentPreviousPointerPath {
    param(
        [Parameter(Mandatory = $true)]
        [string] $DataRoot
    )

    return (Join-Path $DataRoot 'state\previous.json')
}

function Test-CompanyAgentBundleIntegrity {
    param(
        [Parameter(Mandatory = $true)]
        [string] $BundleRoot
    )

    $bundleRootFull = (ConvertTo-CompanyAgentFullPath -Path $BundleRoot).TrimEnd([char[]]@('\', '/'))
    $manifestPath = Join-Path $bundleRootFull 'bundle-manifest.json'
    $manifest = Read-CompanyAgentJson -Path $manifestPath
    if ($manifest.format -ne 'company-agent-offline-bundle/v1') {
        throw "Unsupported bundle format in $manifestPath"
    }

    $expected = @{}
    foreach ($record in @($manifest.files)) {
        $relativePath = [string]$record.path
        if ([string]::IsNullOrWhiteSpace($relativePath) -or [System.IO.Path]::IsPathRooted($relativePath) -or $relativePath -match '(^|/)\.\.(/|$)') {
            throw "Unsafe path in bundle manifest: $relativePath"
        }

        $candidate = ConvertTo-CompanyAgentFullPath -Path (Join-Path $bundleRootFull ($relativePath.Replace('/', '\')))
        $prefix = $bundleRootFull + [System.IO.Path]::DirectorySeparatorChar
        if (-not $candidate.StartsWith($prefix, [System.StringComparison]::OrdinalIgnoreCase)) {
            throw "Bundle path escapes bundle root: $relativePath"
        }
        if (-not (Test-Path -LiteralPath $candidate -PathType Leaf)) {
            throw "Bundle file is missing: $relativePath"
        }

        $actualHash = (Get-FileHash -LiteralPath $candidate -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($actualHash -ne ([string]$record.sha256).ToLowerInvariant()) {
            throw "Bundle hash mismatch: $relativePath"
        }
        if ([int64](Get-Item -LiteralPath $candidate).Length -ne [int64]$record.length) {
            throw "Bundle length mismatch: $relativePath"
        }
        $expected[$relativePath.ToLowerInvariant()] = $true
    }

    foreach ($file in @(Get-ChildItem -LiteralPath $bundleRootFull -Recurse -Force | Where-Object { -not $_.PSIsContainer })) {
        $relativePath = $file.FullName.Substring($bundleRootFull.Length).TrimStart([char[]]@('\', '/')).Replace('\', '/')
        if ($relativePath -ieq 'bundle-manifest.json') {
            continue
        }
        if (-not $expected.ContainsKey($relativePath.ToLowerInvariant())) {
            throw "Unlisted file found in bundle: $relativePath"
        }
    }

    return $manifest
}

function Test-CompanyAgentSelectionEqual {
    param(
        [object] $Left,
        [object] $Right
    )

    if ($null -eq $Left -or $null -eq $Right) {
        return $false
    }

    $leftModelMode = 'explicit-map'
    if ($null -ne $Left.PSObject.Properties['modelConfiguration'] -and
        $null -ne $Left.modelConfiguration.PSObject.Properties['mode']) {
        $leftModelMode = [string]$Left.modelConfiguration.mode
    }
    $rightModelMode = 'explicit-map'
    if ($null -ne $Right.PSObject.Properties['modelConfiguration'] -and
        $null -ne $Right.modelConfiguration.PSObject.Properties['mode']) {
        $rightModelMode = [string]$Right.modelConfiguration.mode
    }

    $leftConfigVersion = ''
    if ($null -ne $Left.PSObject.Properties['configVersion']) {
        $leftConfigVersion = [string]$Left.configVersion
    }
    $rightConfigVersion = ''
    if ($null -ne $Right.PSObject.Properties['configVersion']) {
        $rightConfigVersion = [string]$Right.configVersion
    }

    $leftPythonCommand = ''
    if ($null -ne $Left.PSObject.Properties['runtime'] -and
        $null -ne $Left.runtime.PSObject.Properties['pythonCommand']) {
        $leftPythonCommand = [string]$Left.runtime.pythonCommand
    }
    $rightPythonCommand = ''
    if ($null -ne $Right.PSObject.Properties['runtime'] -and
        $null -ne $Right.runtime.PSObject.Properties['pythonCommand']) {
        $rightPythonCommand = [string]$Right.runtime.pythonCommand
    }

    $leftNormalized = [ordered]@{
        coreVersion      = [string]$Left.coreVersion
        knowledgeVersion = [string]$Left.knowledgeVersion
        configVersion    = $leftConfigVersion
        modelMode        = $leftModelMode
        small             = [string]$Left.modelMap.SMALL
        medium            = [string]$Left.modelMap.MEDIUM
        large             = [string]$Left.modelMap.LARGE
        defaultTier       = [string]$Left.routing.defaultTier
        pythonCommand     = $leftPythonCommand
    }
    $rightNormalized = [ordered]@{
        coreVersion      = [string]$Right.coreVersion
        knowledgeVersion = [string]$Right.knowledgeVersion
        configVersion    = $rightConfigVersion
        modelMode        = $rightModelMode
        small             = [string]$Right.modelMap.SMALL
        medium            = [string]$Right.modelMap.MEDIUM
        large             = [string]$Right.modelMap.LARGE
        defaultTier       = [string]$Right.routing.defaultTier
        pythonCommand     = $rightPythonCommand
    }

    return (($leftNormalized | ConvertTo-Json -Compress) -ceq ($rightNormalized | ConvertTo-Json -Compress))
}
